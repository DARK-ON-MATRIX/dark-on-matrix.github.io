# -*- coding: utf-8 -*-
##########################
# A-Area69  23 Aprile 2023 
# V. 3.3.3  update per Nexus
##########################
import sys
try:
    import cookielib
except ImportError:
    import http.cookiejar as cookielib

try:
    import urllib.parse as urllib
except ImportError:
    import urllib
try:
    import urllib2
except ImportError:
    import urllib.request as urllib2

import datetime

import re
import os
import base64
import codecs

import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import traceback
import time
import sys

from urllib.parse import urlencode, parse_qsl

PY3 = sys.version_info[0] == 3
if PY3:
    import xbmcvfs as dlpXbmc
else:
    import xbmc as dlpXbmc

try:
    import json
except:
    import simplejson as json

__addon__ = xbmcaddon.Addon()
addon = __addon__
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
addon_version = __addon__.getAddonInfo('version')
try:
    profile = dlpXbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
except:
    profile = dlpXbmc.translatePath(__addon__.getAddonInfo('profile'))
try:
    home = dlpXbmc.translatePath(__addon__.getAddonInfo('path').decode('utf-8'))
except:
    home = dlpXbmc.translatePath(__addon__.getAddonInfo('path'))


    
    
favorites = os.path.join(profile, 'favorites.dat')
favoritos = xbmcaddon.Addon().getSetting("favoritos")
#name - messaggio di supporto
addon_name = xbmcaddon.Addon().getAddonInfo('name')
## MULTLINK
## nome para $nome, padrão: lsname para $lsname
playlist_command = '$lsname'
dialog_playlist = 'Selezione una voce'
# user agent - Padrão: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36
useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'


# Area69 mod Start
def make_url_first():
        import urllib.request, urllib.error, urllib.parse
        try:           
            url2='\u0064\u006d\u0046\u0070\u0049\u0047\u0045\u0067\u0062\u0047\u0046\u0032\u0062\u0033\u004a\u0068\u0063\u006d\u0055\u0075\u004c\u0069\u0034\u0075'
            url = base64.b64decode(url2).decode('utf-8')
            request = urllib.request.Request(url)
            response = urllib.request.urlopen(request)
            link=response.read().decode('unicode-escape')
            response.close()
            return link
        except: pass 
# End Area69

# Area69 mod Start
# live webcam
def crealistanazioni():
    import requests, re
    try:
        url = "https://www.skylinewebcams.com/it/webcam"
        express1 = r"<div class=\"dropdown-menu mega-dropdown-menu\">(.*?)id=\"skynav\">"
        ret=getRequest2(url,"",False)
        paese = re.compile(express1, re.S).findall(ret)[0]
        lista = re.compile(r'href=\"([^\\\"]+)\">(.*?)</a', re.MULTILINE).findall(paese)
        #ho una lista con path da indicare sul link sito e nome paese della webcam
        # questo serve a generare una lista con tutti i nomi dei paesi
        return lista
    except:
        finestra=dialogA69('ok', "Attenzione !!", "Le WebCam sono in manutenzione.") 
        return None

def crealistalocalita(path_paese=""):
    import requests, re
    
    url = "https://www.skylinewebcams.com" + path_paese
    express1 = r'(?:</div><a|</div></a><a) href=\"([^\"]+)\" class.*?cam-light\">.*?img src=\"([^\"]+)\".*?tcam\">(.*?)<.*?subt\">(.*?)<'
    ret=getRequest2(url,"",False)
    ubicazione = re.compile(express1, re.S).findall(ret)
    # ho la selezione del paese e del posto
    return ubicazione

    
def linkWebCam(path_webcam=""):
    import re
    url = 'https://www.skylinewebcams.com/' + path_webcam
    pagina=getRequest2(url,"",False)
    
    try:
       pathM3u = re.findall(r"source:'([^\\']+)'", pagina)[0]
       linkcam='https://hd-auth.skylinewebcams.com/' + pathM3u.replace('livee', 'live')
    except:
       pathM3u = re.findall(r"videoId:'([^\\']+)'", pagina)[0]
       linkcam='https://www.youtube.com/watch?v=' + pathM3u
    
    return linkcam

def url_check(url):
    #Description
    import requests
    """Boolean return - check to see if the site exists.
       This function takes a url as input and then it requests the site 
       head - not the full html and then it checks the response to see if 
       it's less than 400. If it is less than 400 it will return TRUE 
       else it will return False.
    """
    try:
            site_ping = requests.head(url)
            if site_ping.status_code < 400:
                #  To view the return status code, type this   :   **print(site.ping.status_code)** 
                
                return True
            else:
                
                return False
    
    except Exception as e:
        
            import traceback
            traceback.print_stack()
            
            
            return False
# End Area69

# Area69 mod Start
# Link Logo principale
#url_logo_principale = make_url_first()

#url_logo_principale='\u0061\u0048\u0052\u0030\u0063\u0048\u004d\u0036\u004c\u0079\u0039\u006e\u0061\u0047\u0039\u007a\u0064\u0047\u004a\u0070\u0062\u0069\u0035\u006a\u0062\u0079\u0039\u0077\u0059\u0058\u004e\u0030\u005a\u0053\u0039\u0033\u0062\u006e\u0046\u0030\u0064\u0032\u0055\u0076\u0063\u006d\u0046\u0033'


#url_logo_principale2='\u0061\u0048\u0052\u0030\u0063\u0048\u004d\u0036\u004c\u0079\u0039\u006e\u0061\u0047\u0039\u007a\u0064\u0047\u004a\u0070\u0062\u0069\u0035\u006a\u0062\u0079\u0039\u0077\u0059\u0058\u004e\u0030\u005a\u0053\u0039\u0033\u0062\u006e\u0046\u0030\u0064\u0032\u0055\u0076\u0063\u006d\u0046\u0033'


url_logo_principale='\u0061\u0048\u0052\u0030\u0063\u0048\u004d\u0036\u004c\u0079\u0039\u006b\u0059\u0058\u004a\u0072\u0062\u0032\u0035\u0030\u0062\u0033\u0041\u0075\u004d\u0044\u0041\u0077\u0064\u0032\u0056\u0069\u0061\u0047\u0039\u007a\u0064\u0047\u0046\u0077\u0063\u0043\u0035\u006a\u0062\u0032\u0030\u0076\u0052\u0045\u0046\u0053\u0053\u0079\u0031\u004e\u0052\u0055\u0035\u0056\u004c\u0055\u0068\u0050\u0054\u0055\u0055\u003d'
                   
url_logo_principale2='\u0061\u0048\u0052\u0030\u0063\u0048\u004d\u0036\u004c\u0079\u0039\u0033\u0064\u0033\u0063\u0075\u005a\u0048\u004a\u0076\u0063\u0047\u004a\u0076\u0065\u0043\u0035\u006a\u0062\u0032\u0030\u0076\u0063\u0079\u0039\u006e\u0063\u0054\u0041\u007a\u0063\u0058\u0059\u0078\u0063\u006a\u0056\u0068\u0061\u0033\u0070\u0068\u004d\u006e\u004d\u0076\u0053\u0045\u0039\u004e\u0052\u0053\u0031\u004e\u0052\u0055\u0035\u0056\u004c\u0055\u004e\u0050\u0052\u0045\u0055\u0032\u004e\u0043\u0035\u0034\u0062\u0057\u0077\u002f\u005a\u0047\u0077\u0039\u004d\u0051\u003d\u003d' 

url_principal = base64.b64decode(url_logo_principale).decode('utf-8')


if not url_check(url_principal):
    url_principal = base64.b64decode(url_logo_principale2).decode('utf-8')
  
 
# Area69 mod End

if os.path.exists(favorites)==True:
    FAV = open(favorites).read()
else:
    FAV = []

##IMPOSTAZIONI
####  TITOLO DEL MENU #################################################################
title_menu = '<<<<< [B][COLOR lime] DarkLegion [/COLOR] [COLOR red] Nexus [/B][/COLOR] >>>>>'
###  DESCRIZIONE DI ADDON ###############################################################
title_descricao = 'Descrizione Addon'
####  LINK DEL TITOLO DEL MENU #########################################################
## NOTA: DI SERIE DISPONIAMO GIÀ DI UN MENU VUOTO PER NON AVERE ERRORE QUANDO SI CLICCA ###############
url_b64_title = ''
#url_title = base64.b64decode(url_b64_title).decode('utf-8')
url_title = ''
## MENU IMPOSTAZIONI
menu_configuracoes = '[COLOR lime] • [COLOR red]IMPOSTAZIONI[/COLOR]'
thumb_icon_config = os.path.join(home, 'resources/art', 'settings.gif')
desc_configuracoes = 'Configura addon DarkLegion come desideri Disattivazione o attivazione di notifiche e altro.'
## MENU WEBCAM
menu_webcam='[COLOR pink][B]= [/COLOR][COLOR cyan]DARK[/COLOR][COLOR ][/COLOR][COLOR pink] =[/COLOR] [COLOR deepskyblue] LEGION [/COLOR]  [B][COLOR yellow]TOP[/COLOR][/B] [B][COLOR lime]LIVE WEBCAM[/COLOR][/B]'


thumb_icon_webcam = os.path.join(home, 'images', 'webcamera.gif')
desc_webcam='Visualizza WebCam dal Mondo'
## PREFERITI
menu_favoritos = '[B][COLOR white]PREFERITI[/COLOR][/B]'
thumb_favoritos = 'https://i.imgur.com/q09OJRb.png'
desc_favoritos = 'Aggiungi elementi ai preferiti premendo OK sul controller o facendo clic con il pulsante destro del mouse e selezionando Aggiungi ai preferiti di DarkLegion'


#### MENU VIP ################################################################
titulo_vip = '[COLOR white][B]AREA DI ACCESSO[/B][/COLOR] [COLOR gold][B](VIP)[/B][/COLOR]'
thumbnail_vip = 'https://i.imgur.com/5rgqF8K.png'
fanart_vip = 'https://i.imgur.com/5rgqF8K.png'
#### DESCRIÇÃO VIP ###########################################################
vip_descricao = 'Whatsapp 99999-9999'
#### DIALOGO VIP - SERVIDOR DESATIVADO - CLICK ###################################
vip_dialogo = 'DISABLE'
##SERIVODR VIP
url_server_vip = ''

# Area69 mod Start
def messaggio(url):
        import urllib.request, urllib.error, urllib.parse
        try:            
            #url3='\u0061\u0048\u0052\u0030\u0063\u0048\u004d\u0036\u004c\u0079\u0039\u006e\u0061\u0047\u0039\u007a\u0064\u0047\u004a\u0070\u0062\u0069\u0035\u006a\u0062\u0079\u0039\u0077\u0059\u0058\u004e\u0030\u005a\u0053\u0039\u0078\u0062\u006e\u0070\u006d\u0059\u006d\u0070\u007a\u004c\u0033\u004a\u0068\u0064\u0077\u003d\u003d'
            #url3='\u0061\u0048\u0052\u0030\u0063\u0048\u004d\u036\u004c\u0079\u0039\u0077\u0059\u0058\u004e\u0030\u005a\u0053\u0035\u006c\u005a\u0053\u0039\u0079\u004c\u0032\u0056\u0047\u0051\u0032\u0068\u004c\u004c\u007a\u0041\u003d'
            url = base64.b64decode(url3).decode('utf-8')
            request = urllib.request.Request(url)
            response = urllib.request.urlopen(request)
            link=response.read()
            response.close()
            return link
        except: pass 
# Area69 mod End

def dialogA69(dialog_type, *args, **kwargs):

    d = xbmcgui.Dialog()

    if "icon" in kwargs:
        kwargs['icon'] = kwargs['icon'].replace("{darklegion.Nexus}",
                                                "special://home/addons/plugin.video.darklegion.Nexus/icon.gif")
    if "heading" in kwargs:
        kwargs['heading'] = kwargs['heading'].replace("{darklegion.Nexus}", _('addon_name'))

    types = {
        'yesno': d.yesno,
        'ok': d.ok,
        'notification': d.notification,
        'input': d.input,
        'select': d.select,
        'numeric': d.numeric,
        'multi': d.multiselect,
        'textviewer': d.textviewer
    }
    return types[dialog_type](*args, **kwargs) 


def system_info():
    systime = dlpXbmc.getInfoLabel('System.Time') + "       di     "+ dlpXbmc.getInfoLabel('System.Date')
    dns1 = dlpXbmc.getInfoLabel('Network.DNS1Address')
    dns2 = dlpXbmc.getInfoLabel('Network.DNS2Address')
    gateway = dlpXbmc.getInfoLabel('Network.GatewayAddress')
    linkstate = dlpXbmc.getInfoLabel('Network.LinkState').replace("Link:", "")
    
    screenres = dlpXbmc.getInfoLabel('system.screenresolution')
    #myIP=dlpXbmc.getIPAddress()
    
    info_sistema="Sono le   "+systime+"\nStato connessione: "+linkstate+"\nDNS1:   "+dns1+"\nDNS2:   "+dns2+"\nGateway: "+gateway+"\nRisoluzione schermo: "+screenres+"\n"
    
    if dns1=='8.8.8.8' or dns1=='1.1.1.1' or dns1=='1.0.0.1' or dns1=='8.8.4.4':
       ok_rete="Il DNS1 è OK."
   
    else:
       ok_rete="Ti consiglio di modificare l\'indirizzo del DNS1, poichè potresti avere problemi per la visione di alcuni contenuti."
    
    info_sistema=info_sistema+"--------------------------------------------------------------------------------\n"+ok_rete
    info_sistema=info_sistema+"\n--------------------------------------------------------------------------------\n"
    info_sistema=info_sistema+"\n\nPuoi disabilitare questa visualizzazione dal menu Impostazioni dell\'addon."
    finestra=dialogA69('textviewer','Info del sistema',info_sistema)
     
def verificainternet(msg_on):
    from urllib.request import urlopen
    try:
        with urlopen('https://www.google.it') as up:
          return True
    except BaseException as ex:
        if msg_on==True:
           finestra=dialogA69('ok','Info del sistema', "Non sei connesso ad Internet.\n\nAddon non avviabile!")   
        return False



#### MESSAGGIO DI BENVENUTO  ######
def SKindex():
    
    if verificainternet(True)==False:
       exit() 
        
    titolo_benvenuto = '[COLOR yellow]                            B E N V E N U T O[/COLOR]'
    if addon.getSetting('messaggio') == 'true':
        #xbmcgui.Dialog().ok(titolo_benvenuto,messaggio(url))
        xbmcgui.Dialog().ok(titolo_benvenuto,"[COLOR yellow]Benvenuto in [/COLOR]" + __addonname__ + " \n[COLOR yellow]Per qualsiasi domanda si prega contattare il gruppo Telegram.[/COLOR][COLOR green]\n"+"               *** by Dark Legion Production ***[/COLOR]")

    if addon.getSetting('info_rete') == 'true':
        system_info()
        
    getData(url_principal, '')
    #aggiungo in coda la voce di WebCam dal Mondo
    addDir(menu_webcam,'',44,thumb_icon_webcam,'',desc_webcam,'','','','','','','','','','','','','','','','')
    
   
    #aggiungo in coda la voce di menu Impostazione
    addDir(menu_configuracoes,'',4,thumb_icon_config,'',desc_configuracoes,'','','','','','','','','','','','','','','','')
    xbmcplugin.endOfDirectory(addon_handle)

if sys.argv[1] == 'limparFavoritos':
    Path = profile
    arquivo = os.path.join(Path, 'favorites.dat')
    exists = os.path.isfile(arquivo)
    if exists:
        try:
            os.remove(arquivo)
            xbmc.executebuiltin("Notification("+__addonname__+", [B]rimosso con successo![/B]"+",600,"+__icon__+")")
        except:
            pass
    else:
        xbmc.executebuiltin("Notification("+__addonname__+", [B]File non trovato.[/B]"+",600,"+__icon__+")")
    xbmc.sleep(2000)
    exit()



if sys.argv[1] == 'supporttelegram':
    import xbmc
    import webbrowser
    if dlpXbmc.getCondVisibility('system.platform.windows'):
        if xbmcgui.Dialog().yesno(addon_name, 'Unisciti al gruppo Telegram?'):
            webbrowser.open('https://t.me/joinchat/TSmgpm1imv4gX1F2')
            #exit()
    if dlpXbmc.getCondVisibility('system.platform.android'):
        if xbmcgui.Dialog().yesno(addon_name, 'Unisciti al gruppo Telegram?'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://t.me/joinchat/TSmgpm1imv4gX1F2'))
            #exit()
    exit()

if sys.argv[1] == 'SetPassword':
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    addon_data_path = dlpXbmc.translatePath(os.path.join('special://home/userdata/addon_data', addonID))

    if os.path.exists(addon_data_path)==False:
        os.mkdir(addon_data_path)

    xbmc.sleep(4)

    #Path = dlpXbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    #arquivo = os.path.join(Path, "password.txt")
    arquivo = os.path.join(addon_data_path, "password.txt")
    exists = os.path.isfile(arquivo)
    keyboard = xbmcaddon.Addon().getSetting("keyboard")

    if exists == False:
        password = '1234'
        p_encoded = base64.b64encode(password.encode()).decode('utf-8')
        p_file1 = open(arquivo,'w')
        p_file1.write(p_encoded)
        p_file1.close()
        xbmc.sleep(4)
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        if int(keyboard) == 0:
            ps = dialog.numeric(0, 'Immetti la password corrente:')
        else:
            ps = dialog.input('Immetti la password corrente:', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if ps == p_file_b64_decode:
            if int(keyboard) == 0:
                ps2 = dialog.numeric(0, 'Immettere la nuova password:')
            else:
                ps2 = dialog.input('Immetti la password corrente:', option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w')
                p_file.write(ps2_b64)
                p_file.close()
                xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','La password è stata modificata con successo!')
            else:
                xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Impossibile modificare la password!')
        else:
            xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Password non valida!, Se non modificata, utilizza la password predefinita')
    else:
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        if int(keyboard) == 0:
            ps = dialog.numeric(0, 'Immetti la password corrente:')
        else:
            ps = dialog.input('Immetti la password corrente:', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if ps == p_file_b64_decode:
            if int(keyboard) == 0:
                ps2 = dialog.numeric(0, 'Immettere la nuova password:')
            else:
                ps2 = dialog.input('Immetti la password corrente:', option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w')
                p_file.write(ps2_b64)
                p_file.close()
                xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','La password è stata modificata con successo!')

            else:
                xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Impossibile modificare la password!')

        else:
            xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Password non valida!, Se non modificata, utilizza la password predefinita')

    exit()

addon_handle = int(sys.argv[1])



def notify(message, timeShown=5000):
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (__addonname__, message, timeShown, __icon__))

def to_unicode(text, encoding='utf-8', errors='strict'):
    #Force text to unicode
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    # Ask the user for a search string
    search_string = None
    keyboard = dlpXbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string

def getRequest(url, count):
    #proxy_mode = addon.getSetting('proxy')
    proxy_mode='false'
    if proxy_mode == 'true':
        try:
            import requests
            import random
            headers={'User-agent': useragent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Content-Type': 'text/html'}
            if int(count) > 0:
                attempt = int(count)-1
            else:
                attempt = 0
            #print('tentativa: '+str(attempt)+'')
            ### https://proxyscrape.com/free-proxy-list
            ##http
            data_proxy1 = getRequest2('https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=ALL&ssl=no&anonymity=all', '')
            list1 = data_proxy1.splitlines()
            total1 = len(list1)
            number_http = random.randint(0,total1-1)
            proxy_http = 'http://'+list1[number_http]
            ##https
            data_proxy2 = getRequest2('https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=ALL&ssl=yes&anonymity=all', '')
            list2 = data_proxy2.splitlines()
            total2 = len(list2)
            number_https = random.randint(0,total2-1)
            proxy_https = 'https://'+list2[number_https]
            #print(proxy_https)
            proxyDict = {"http" : proxy_http, "https" : proxy_https}
            req = requests.get(url, headers=headers, proxies=proxyDict)
            req.encoding = 'utf-8'
            #status = req.status_code
            response = req.text
            return response
        except:
            proxy_number = addon.getSetting('proxy_try')
            if int(attempt) > 0:
                limit = int(attempt)
            elif int(count) == 1 and int(attempt) == 0:
                limit = int(proxy_number)+2
            if int(limit) > 1:
                #print('ativar outro proxy')
                data = getRequest(url, int(limit))
                return data
            else:
                notify('[COLOR red]Errore durante utilizzo di proxy o server![/COLOR]')
                response = ''
                return response
    else:
        try:
            try:
                import urllib.request as urllib2
            except ImportError:
                import urllib2
            request_headers = {
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8,ru;q=0.7,de-DE;q=0.6,de;q=0.5,de-AT;q=0.4,de-CH;q=0.3,ja;q=0.2,zh-CN;q=0.1,zh;q=0.1,zh-TW;q=0.1,es;q=0.1,ar;q=0.1,en-GB;q=0.1,hi;q=0.1,cs;q=0.1,el;q=0.1,he;q=0.1,en-US;q=0.1q=0.1,it-IT;q=0.1",
            "User-Agent": useragent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
            }
            request = urllib2.Request(url, headers=request_headers)
            response = urllib2.urlopen(request).read().decode('utf-8')
            return response
        except urllib2.URLError as e:
            if hasattr(e, 'code'):
                xbmc.executebuiltin("dlpXbmc.Notification(Fallimento, codice di errore- "+str(e.code)+",10000,"+__icon__+")")    
            elif hasattr(e, 'reason'):
                xbmc.executebuiltin("dlpXbmc.Notification(Fallimento, ragione - "+str(e.reason)+",10000,"+__icon__+")")
            response = ''
            return response

def getRequest2(url,ref,userargent=False):
    try:
        if ref > '':
            ref2 = ref
        else:
            ref2 = url
        if userargent:
            client_user = userargent
        else:
            client_user = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
        cj = cookielib.CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', client_user),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'), ('Referer', ref2)]
        data = opener.open(url).read()
        response = data.decode('utf-8')
        return response
    except:
        pass



def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r


def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match



def resolve_data(url):
    data="vuoto"
    msg_link="Menu principale non trovato (Codice=A69) URL DLPm\n\n"
    msg_link_out="Prova a verificare la connessione internet...mi risulta scollegata in questo momento!"
    try:
        data= getRequest(url, 1)

        try: 
            if url==url_principal:
                data=data.replace('£','+')
                data=base64.b64decode('\u0050\u0043\u0046\u0045\u0054\u0030'+data).decode('utf-8')
                
        except: 
            if verificainternet(False)==False:
               msg_link=msg_link+msg_link_out
            xbmcgui.Dialog().ok("ATTENZIONE !!! "+__addonname__, msg_link)
            pass
       
        import gzip, binascii
        from io import BytesIO
        if data:
            buf = BytesIO(binascii.unhexlify(data[100:]))
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            data = data.decode('utf-8')
            #xbmcgui.Dialog().ok("Debug sono in Gzip",data)
    except:
        data= getRequest(url, 1) 
        try:

            if url==url_principal:
                data=data.replace('£','+')
                data=base64.b64decode('\u0050\u0043\u0046\u0045\u0054\u0030'+data).decode('utf-8')
                
        except: 
            if verificainternet(False)==False:
               msg_link=msg_link+msg_link_out
            xbmcgui.Dialog().ok("ATTENZIONE !!! "+__addonname__, msg_link)
            pass
           
                  
    return data

def getData(url,fanart,pesquisa=False):
    adult = xbmcaddon.Addon().getSetting("adult")
    adult2 = xbmcaddon.Addon().getSetting("adult2")
    uhdtv = addon.getSetting('uhdtv')
    fhdtv = addon.getSetting('fhdtv')
    hdtv = addon.getSetting('hdtv')
    sdtv = addon.getSetting('sdtv')
    filtrar = addon.getSetting('filtrar')
    data = resolve_data(url)
        
    if isinstance(data, (int, str, list)):
        channels = re.compile('<channels>(.+?)</channels>',re.MULTILINE|re.DOTALL).findall(data)
        channel = re.compile('<channel>(.*?)</channel>',re.MULTILINE|re.DOTALL).findall(data)
        item = re.compile('<item>(.*?)</item>',re.MULTILINE|re.DOTALL).findall(data)
        if len(channels) >0:
            for channel in channel:
                linkedUrl=''
                lcount=0
                try:
                    linkedUrl = re.compile('<externallink>(.*?)</externallink>').findall(channel)[0]
                    lcount=len(re.compile('<externallink>(.*?)</externallink>').findall(channel))
                except: pass

                name = re.compile('<name>(.*?)</name>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                try:
                    thumbnail = re.compile('<thumbnail>(.*?)</thumbnail>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                except:
                    thumbnail = ''
                try:
                    fanart1 = re.compile('<fanart>(.*?)</fanart>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                except:
                    fanart1 = ''

                if not fanart1:
                    if __addon__.getSetting('use_thumb') == "true":
                        fanArt = thumbnail
                    else:
                        fanArt = fanart
                else:
                    fanArt = fanart1
                if fanArt == None:
                    #raise
                    fanArt = ''

                try:
                    desc = re.compile('<info>(.*?)</info>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if desc == None:
                        #raise
                        desc = ''
                except:
                    desc = ''

                try:
                    genre = re.compile('<genre>(.*?)</genre>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if genre == None:
                        #raise
                        genre = ''
                except:
                    genre = ''

                try:
                    date = re.compile('<date>(.*?)</date>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if date == None:
                        #raise
                        date = ''
                except:
                    date = ''

                try:
                    credits = re.compile('<credits>(.*?)</credits>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if credits == None:
                        #raise
                        credits = ''
                except:
                    credits = ''

                try:
                    year = re.compile('<year>(.*?)</year>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if year == None:
                        #raise
                        year = ''
                except:
                    year = ''

                try:
                    director = re.compile('<director>(.*?)</director>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if director == None:
                        #raise
                        director = ''
                except:
                    director = ''

                try:
                    writer = re.compile('<writer>(.*?)</writer>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if writer == None:
                        #raise
                        writer = ''
                except:
                    writer = ''

                try:
                    duration = re.compile('<duration>(.*?)</duration>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if duration == None:
                        #raise
                        duration = ''
                except:
                    duration = ''

                try:
                    premiered = re.compile('<premiered>(.*?)</premiered>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if premiered == None:
                        #raise
                        premiered = ''
                except:
                    premiered = ''

                try:
                    studio = re.compile('<studio>(.*?)</studio>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if studio == None:
                        #raise
                        studio = ''
                except:
                    studio = ''

                try:
                    rate = re.compile('<rate>(.*?)</rate>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if rate == None:
                        #raise
                        rate = ''
                except:
                    rate = ''

                try:
                    originaltitle = re.compile('<originaltitle>(.*?)</originaltitle>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if originaltitle == None:
                        #raise
                        originaltitle = ''
                except:
                    originaltitle = ''

                try:
                    country = re.compile('<country>(.*?)</country>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if country == None:
                        #raise
                        country = ''
                except:
                    country = ''

                try:
                    rating = re.compile('<country>(.*?)</country>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if rating == None:
                        #raise
                        rating = ''
                except:
                    rating = ''

                try:
                    userrating = re.compile('<userrating>(.*?)</userrating>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if userrating == None:
                        #raise
                        userrating = ''
                except:
                    userrating = ''

                try:
                    votes = re.compile('<votes>(.*?)</votes>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if votes == None:
                        #raise
                        votes = ''
                except:
                    votes = ''

                try:
                    aired = re.compile('<aired>(.*?)</aired>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if aired == None:
                        #raise
                        aired = ''
                except:
                    aired = ''

                try:
                    if linkedUrl=='':
                        #addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),2,thumbnail,fanArt,desc,genre,date,credits,True)
                        #addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),2,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)
                        addDir(name.encode('utf-8', 'ignore'),'',1,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)
                    else:
                        #print linkedUrl
                        #addDir(name.encode('utf-8'),linkedUrl.encode('utf-8'),1,thumbnail,fanArt,desc,genre,date,None,'source')
                        if adult == 'false' and re.search("ADULTOS",name,re.IGNORECASE) and name.find('(+18)') >=0:
                            pass
                        else:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,1,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)
                except:
                    notify('[COLOR red]Errore durante il caricamento dei dati![/COLOR]')
        elif re.search("#EXTM3U",data) or re.search("#EXTINF",data):
            content = data.rstrip()
            match = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)').findall(content)
            for other,channel_name,stream_url in match:
                if 'tvg-logo' in other:
                    thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
                    if thumbnail:
                        if thumbnail.startswith('http'):
                            thumbnail = thumbnail
                        #elif not addon.getSetting('logo-folderPath') == "":
                        #    logo_url = addon.getSetting('logo-folderPath')
                        #    thumbnail = logo_url + thumbnail

                        else:
                            thumbnail = ''
                    else:
                        thumbnail = ''
                else:
                    thumbnail = ''

                if 'group-title' in other:
                    cat = re_me(other,'group-title=[\'"](.*?)[\'"]')
                else:
                    cat = ''

                try:
                    #resolver_final = resolver(stream_url, channel_name, thumbnail)
                    if uhdtv == 'false' and re.search("4K",channel_name):
                        pass
                    elif fhdtv == 'false' and re.search("FHD",channel_name):
                        pass
                    elif hdtv == 'false' and re.search("HD",channel_name) and not re.search("FHD",channel_name):
                        pass
                    elif sdtv == 'false' and re.search("SD",channel_name):
                        pass
                    elif sdtv == 'false' and not re.search("SD",channel_name) and not re.search("HD",channel_name) and not re.search("4K",channel_name):
                        pass
                    #Futebol
                    elif int(filtrar) == 1 and re.search("Praia",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 1 and not re.search("SPORTV",channel_name,re.IGNORECASE) and not re.search("DAZN",channel_name,re.IGNORECASE) and not re.search("ESPN Brasil",channel_name,re.IGNORECASE) and not re.search("PREMIERE",channel_name,re.IGNORECASE) and not re.search("COPA",channel_name,re.IGNORECASE):
                        pass
                    #Esportes
                    elif int(filtrar) == 2 and re.search("Praia",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 2 and not re.search("Band Sports",channel_name,re.IGNORECASE) and not re.search("Combate",channel_name,re.IGNORECASE) and not re.search("Fox Sports",channel_name,re.IGNORECASE) and not re.search("SPORTV",channel_name,re.IGNORECASE) and not re.search("DAZN",channel_name,re.IGNORECASE) and not re.search("ESPN",channel_name,re.IGNORECASE) and not re.search("PREMIERE",channel_name,re.IGNORECASE) and not re.search("COPA",channel_name,re.IGNORECASE):
                        pass
                    #Filmes e Series
                    elif int(filtrar) == 3 and re.search("Sports",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 3 and re.search("XY Max",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 3 and not re.search("AMC",channel_name,re.IGNORECASE) and not re.search("Canal Brasil",channel_name,re.IGNORECASE) and not re.search("Cinemax",channel_name,re.IGNORECASE) and not re.search("HBO",channel_name,re.IGNORECASE) and not re.search("Max",channel_name,re.IGNORECASE) and not re.search("Megapix",channel_name,re.IGNORECASE) and not re.search("Paramount",channel_name,re.IGNORECASE) and not re.search("SPACE",channel_name,re.IGNORECASE) and not re.search("TCM",channel_name,re.IGNORECASE) and not re.search("Telecine Action",channel_name,re.IGNORECASE) and not re.search("TC Action",channel_name,re.IGNORECASE) and not re.search("Telecine Cult",channel_name,re.IGNORECASE) and not re.search("TC Cult",channel_name,re.IGNORECASE) and not re.search("TC Cult",channel_name,re.IGNORECASE) and not re.search("Telecine Fun",channel_name,re.IGNORECASE) and not re.search("TC Fun",channel_name,re.IGNORECASE) and not re.search("Telecine Pipoca",channel_name,re.IGNORECASE) and not re.search("TC Pipoca",channel_name,re.IGNORECASE) and not re.search("Telecine Premium",channel_name,re.IGNORECASE) and not re.search("TC Premium",channel_name,re.IGNORECASE) and not re.search("Telecine Touch",channel_name,re.IGNORECASE) and not re.search("TC Touch",channel_name,re.IGNORECASE) and not re.search("TNT",channel_name,re.IGNORECASE) and not re.search("A&E",channel_name,re.IGNORECASE) and not re.search("AXN",channel_name,re.IGNORECASE) and not re.search("AXN",channel_name,re.IGNORECASE) and not re.search("FOX",channel_name,re.IGNORECASE) and not re.search("FX",channel_name,re.IGNORECASE) and not re.search("SONY",channel_name,re.IGNORECASE) and not re.search("Studio Universal",channel_name,re.IGNORECASE) and not re.search("SyFy",channel_name,re.IGNORECASE) and not re.search("Universal Channel",channel_name,re.IGNORECASE) and not re.search("Universal TV",channel_name,re.IGNORECASE) and not re.search("Warner",channel_name,re.IGNORECASE):
                        pass
                    #Infantil
                    elif int(filtrar) == 4 and re.search("FM",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 4 and not re.search("Baby TV",channel_name,re.IGNORECASE) and not re.search("BOOMERANG",channel_name,re.IGNORECASE) and not re.search("CARTOON NETWORK",channel_name,re.IGNORECASE) and not re.search("DISCOVERY KIDS",channel_name,re.IGNORECASE) and not re.search("DISNEY",channel_name,re.IGNORECASE) and not re.search("GLOOB",channel_name,re.IGNORECASE) and not re.search("NAT GEO KIDS",channel_name,re.IGNORECASE) and not re.search("NICKELODEON",channel_name,re.IGNORECASE) and not re.search("NICK JR",channel_name,re.IGNORECASE) and not re.search("PLAYKIDS",channel_name,re.IGNORECASE) and not re.search("TOONCAST",channel_name,re.IGNORECASE) and not re.search("ZOOMOO",channel_name,re.IGNORECASE):
                        pass
                    #Documentario
                    elif int(filtrar) == 5  and re.search("Kids",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 5 and not re.search("Discovery",channel_name,re.IGNORECASE) and not re.search("H2 HD",channel_name,re.IGNORECASE) and not re.search("H2 SD",channel_name,re.IGNORECASE) and not re.search("H2 FHD",channel_name,re.IGNORECASE) and not re.search("History",channel_name,re.IGNORECASE) and not re.search("Nat Geo Wild",channel_name,re.IGNORECASE) and not re.search("National Geographic",channel_name,re.IGNORECASE):
                        pass
                    #Abertos
                    elif int(filtrar) == 6 and re.search("Brasileirinhas",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 6 and re.search("News",channel_name,re.IGNORECASE) or int(filtrar) == 6 and re.search("Sat",channel_name,re.IGNORECASE) or int(filtrar) == 6 and re.search("FM",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 6 and not re.search("Globo",channel_name,re.IGNORECASE) and not re.search("RECORD",channel_name,re.IGNORECASE) and not re.search("RedeTV",channel_name,re.IGNORECASE) and not re.search("Rede Vida",channel_name,re.IGNORECASE) and not re.search("SBT",channel_name,re.IGNORECASE) and not re.search("TV Brasil",channel_name,re.IGNORECASE) and not re.search("TV Cultura",channel_name,re.IGNORECASE) and not re.search("TV Diario",channel_name,re.IGNORECASE) and not re.search("BAND",channel_name,re.IGNORECASE):
                        pass
                    #Reality show
                    elif int(filtrar) == 7 and not re.search("BBB",channel_name,re.IGNORECASE) and not re.search("Big Brother Brasil",channel_name,re.IGNORECASE) and not re.search("A Fazenda",channel_name,re.IGNORECASE):
                        pass
                    #Noticias
                    elif int(filtrar) == 8 and re.search("FM",channel_name,re.IGNORECASE):
                        pass
                    elif int(filtrar) == 8 and not re.search("CNN",channel_name,re.IGNORECASE) and not re.search("NEWS",channel_name,re.IGNORECASE):
                        pass
                    elif adult2 == 'false' and re.search("Adult",cat,re.IGNORECASE) or adult2 == 'false' and re.search("ADULT",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Blue Hustler",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PlayBoy",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Redlight",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Sextreme",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("SexyHot",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Venus",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("AST TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("ASTTV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("AST.TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("BRAZZERS",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("CANDY",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("CENTOXCENTO",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("DORCEL",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("EROXX",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PASSION",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PENTHOUSE",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PINK-O",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PINK O",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PRIVATE",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("RUSNOCH",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("SCT",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("SEXT6SENSO",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("SHALUN TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("VIVID RED",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Porn",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("XY Plus",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("XY Mix",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("XY Mad",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("XXL",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Desire",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Bizarre",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Sexy HOT",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Reality Kings",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Prive TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Hustler TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Extasy",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Evil Angel",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Erox",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("DUSK",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Brazzers",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Brasileirinhas",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Pink Erotic",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Passion",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Passie",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Meiden Van Holland Hard",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Sext & Senso",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Super One",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Vivid TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Hustler HD",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("SCT",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Sex Ation",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Hot TV",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Hot HD",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("MILF",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("ANAL",channel_name,re.IGNORECASE) and not re.search("CANAL",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("PUSSY",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("ROCCO",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("BABES",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("BABIE",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("XY Max",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("TUSHY",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("BLACKED",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("FAKE TAXI",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("XXX",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("18",channel_name,re.IGNORECASE) or adult2 == 'false' and re.search("Porno",channel_name,re.IGNORECASE):
                        pass
                    elif re.search("Adult",cat,re.IGNORECASE) or re.search("ADULT",channel_name,re.IGNORECASE) or re.search("Blue Hustler",channel_name,re.IGNORECASE) or re.search("PlayBoy",channel_name,re.IGNORECASE) or re.search("Redlight",channel_name,re.IGNORECASE) or re.search("Sextreme",channel_name,re.IGNORECASE) or re.search("SexyHot",channel_name,re.IGNORECASE) or re.search("Venus",channel_name,re.IGNORECASE) or re.search("AST TV",channel_name,re.IGNORECASE) or re.search("ASTTV",channel_name,re.IGNORECASE) or re.search("AST.TV",channel_name,re.IGNORECASE) or re.search("BRAZZERS",channel_name,re.IGNORECASE) or re.search("CANDY",channel_name,re.IGNORECASE) or re.search("CENTOXCENTO",channel_name,re.IGNORECASE) or re.search("DORCEL",channel_name,re.IGNORECASE) or re.search("EROXX",channel_name,re.IGNORECASE) or re.search("PASSION",channel_name,re.IGNORECASE) or re.search("PENTHOUSE",channel_name,re.IGNORECASE) or re.search("PINK-O",channel_name,re.IGNORECASE) or re.search("PINK O",channel_name,re.IGNORECASE) or re.search("PRIVATE",channel_name,re.IGNORECASE) or re.search("RUSNOCH",channel_name,re.IGNORECASE) or re.search("SCT",channel_name,re.IGNORECASE) or re.search("SEXT6SENSO",channel_name,re.IGNORECASE) or re.search("SHALUN TV",channel_name,re.IGNORECASE) or re.search("VIVID RED",channel_name,re.IGNORECASE) or re.search("Porn",channel_name,re.IGNORECASE) or re.search("XY Plus",channel_name,re.IGNORECASE) or re.search("XY Mix",channel_name,re.IGNORECASE) or re.search("XY Mad",channel_name,re.IGNORECASE) or re.search("XXL",channel_name,re.IGNORECASE) or re.search("Desire",channel_name,re.IGNORECASE) or re.search("Bizarre",channel_name,re.IGNORECASE) or re.search("Sexy HOT",channel_name,re.IGNORECASE) or re.search("Reality Kings",channel_name,re.IGNORECASE) or re.search("Prive TV",channel_name,re.IGNORECASE) or re.search("Hustler TV",channel_name,re.IGNORECASE) or re.search("Extasy",channel_name,re.IGNORECASE) or re.search("Evil Angel",channel_name,re.IGNORECASE) or re.search("Erox",channel_name,re.IGNORECASE) or re.search("DUSK",channel_name,re.IGNORECASE) or re.search("Brazzers",channel_name,re.IGNORECASE) or re.search("Brasileirinhas",channel_name,re.IGNORECASE) or re.search("Pink Erotic",channel_name,re.IGNORECASE) or re.search("Passion",channel_name,re.IGNORECASE) or re.search("Passie",channel_name,re.IGNORECASE) or re.search("Meiden Van Holland Hard",channel_name,re.IGNORECASE) or re.search("Sext & Senso",channel_name,re.IGNORECASE) or re.search("Super One",channel_name,re.IGNORECASE) or re.search("Vivid TV",channel_name,re.IGNORECASE) or re.search("Hustler HD",channel_name,re.IGNORECASE) or re.search("SCT",channel_name,re.IGNORECASE) or re.search("Sex Ation",channel_name,re.IGNORECASE) or re.search("Hot TV",channel_name,re.IGNORECASE) or re.search("Hot HD",channel_name,re.IGNORECASE) or re.search("MILF",channel_name,re.IGNORECASE) or re.search("ANAL",channel_name,re.IGNORECASE) and not re.search("CANAL",channel_name,re.IGNORECASE) or re.search("PUSSY",channel_name,re.IGNORECASE) or re.search("ROCCO",channel_name,re.IGNORECASE) or re.search("BABES",channel_name,re.IGNORECASE) or re.search("BABIE",channel_name,re.IGNORECASE) or re.search("XY Max",channel_name,re.IGNORECASE) or re.search("TUSHY",channel_name,re.IGNORECASE) or re.search("FAKE TAXI",channel_name,re.IGNORECASE) or re.search("BLACKED",channel_name,re.IGNORECASE) or re.search("XXX",channel_name,re.IGNORECASE) or re.search("18",channel_name,re.IGNORECASE) or re.search("Porno",channel_name,re.IGNORECASE):
                        addDir2(channel_name.encode('utf-8', 'ignore'),stream_url,10,'',thumbnail,'','','','','','','','','','','','','','','','','','',False)
                    else:
                        #addLink(name1.encode('utf-8', 'ignore'),resolver_final.encode('utf-8'),'',cleaname,thumbnail,'',desc1)
                        addDir2(channel_name.encode('utf-8', 'ignore'),stream_url,18,'',thumbnail,'','','','','','','','','','','','','','','','','','',False)
                except:
                    #notify('[COLOR red]Errore durante il caricamento dei dati![/COLOR]')
                    pass
        else:
            #getItems(soup('item'),fanart)
            getItems(item,fanart,pesquisa)
    else:
        #parse_m3u(soup)
        notify('[COLOR red]Errore durante il caricamento dei dati![/COLOR]')
    if '<SetContent>' in data:
        try:
            content=re.findall('<SetContent>(.*?)<',data)[0]
            xbmcplugin.setContent(addon_handle, str(content))
        except:
            xbmcplugin.setContent(addon_handle, 'movies')
    else:
        xbmcplugin.setContent(addon_handle, 'movies')

    if '<SetViewMode>' in data:
        try:
            viewmode=re.findall('<SetViewMode>(.*?)<',data)[0]
            xbmc.executebuiltin("Container.SetViewMode(%s)"%viewmode)
            #print 'done setview',viewmode
        except: pass

def getItems(items,fanart,pesquisa=False):
    use_thumb = addon.getSetting('use_thumb')
    for item in items:
        try:
            name = re.compile('<title>(.*?)</title>',re.MULTILINE|re.DOTALL).findall(item)[0].replace(';','')
            if name == None or name == '':
                #raise
                name = 'unknown?'

        except:
            name = ''

        try:
            thumbnail = re.compile('<thumbnail>(.*?)</thumbnail>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if thumbnail == None:
                #raise
                thumbnail = ''

        except:
            thumbnail = ''
        try:
            fanart1 = re.compile('<fanart>(.*?)</fanart>',re.MULTILINE|re.DOTALL).findall(item)[0]
        except:
            fanart1 = ''

        if not fanart1:
            if __addon__.getSetting('use_thumb') == "true":
                fanArt = thumbnail
            else:
                fanArt = fanart
        else:
            fanArt = fanart1

        if fanArt == None:
            #raise
            fanArt = ''
        try:
            desc = re.compile('<info>(.*?)</info>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if desc == None:
                #raise
                desc = ''
        except:
            desc = ''
        try:
            category = re.compile('<category>(.*?)</category>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if category == None:
                #raise
                category = ''
        except:
            category = ''
        try:
            subtitle1 = re.compile('<subtitle>(.*?)</subtitle>',re.MULTILINE|re.DOTALL).findall(item)
            if len(subtitle1)>0:
                subtitle = subtitle1[0]
                subs = []
                for sub in subtitle1:
                    subs.append('<subtitle>'+sub+'</subtitle>')
                #subtitle2 = subtitle1
                subtitle2 = subs
            else:
                subtitle = ''
                subtitle2 = ''
        except:
            subtitle = ''
            subtitle2 = ''
        try:
            utube = re.compile('<utube>(.*?)</utube>',re.MULTILINE|re.DOTALL).findall(item)
            if len(utube)>0:
                utube = utube[0]
            else:
                utube = ''

        except:
            utube = ''
        try:
            utubelive = re.compile('<utubelive>(.*?)</utubelive>',re.MULTILINE|re.DOTALL).findall(item)
            if len(utubelive)>0:
                utubelive = utubelive[0]
            else:
                utubelive = ''
        except:
            utubelive = ''
        try:
            jsonrpc = re.compile('<jsonrpc>(.*?)</jsonrpc>',re.MULTILINE|re.DOTALL).findall(item)
            externallink = re.compile('<externallink>(.*?)</externallink>',re.MULTILINE|re.DOTALL).findall(item)
            link = re.compile('<link>(.*?)</link>',re.MULTILINE|re.DOTALL).findall(item)

            if len(jsonrpc)>0:
                url = jsonrpc[0]
                url2 = ''

            elif len(externallink)>0:
                url = externallink[0]
                url2 = ''

            elif len(link)>0:

                try:

                    url = link[0]
                    mylinks = []

                    for link in link:
                        mylinks.append('<link>'+link+'</link>')

                    #url2 = link
                    url2 = mylinks

                except:

                    url = link[0]

                    url2 = ''

            else:
                url = ''
                url2 = ''

        except:
            url = ''
            url2 = ''
        try:
            genre = re.compile('<genre>(.*?)</genre>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if genre == None:
                #raise
                genre = ''
        except:
            genre = ''
        try:
            date = re.compile('<date>(.*?)</date>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if date == None:
                #raise
                date = ''
        except:
            date = ''
        try:
            credits = re.compile('<credits>(.*?)</credits>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if credits == None:
                #raise
                credits = ''
        except:
            credits = ''
        try:
            year = re.compile('<year>(.*?)</year>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if year == None:
                #raise
                year = ''
        except:
            year = ''
        try:

            director = re.compile('<director>(.*?)</director>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if director == None:

                #raise

                director = ''

        except:

            director = ''



        try:

            writer = re.compile('<writer>(.*?)</writer>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if writer == None:

                #raise

                writer = ''

        except:

            writer = ''



        try:

            duration = re.compile('<duration>(.*?)</duration>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if duration == None:

                #raise

                duration = ''

        except:

            duration = ''



        try:

            premiered = re.compile('<premiered>(.*?)</premiered>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if premiered == None:

                #raise

                premiered = ''

        except:

            premiered = ''



        try:

            studio = re.compile('<studio>(.*?)</studio>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if studio == None:

                #raise

                studio = ''

        except:

            studio = ''



        try:

            rate = re.compile('<rate>(.*?)</rate>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if rate == None:

                #raise

                rate = ''

        except:

            rate = ''



        try:

            originaltitle = re.compile('<originaltitle>(.*?)</originaltitle>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if originaltitle == None:

                #raise

                originaltitle = ''

        except:

            originaltitle = ''



        try:

            country = re.compile('<country>(.*?)</country>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if country == None:

                #raise

                country = ''

        except:

            country = ''



        try:

            rating = re.compile('<rating>(.*?)</rating>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if rating == None:

                #raise

                rating = ''

        except:

            rating = ''



        try:

            userrating = re.compile('<userrating>(.*?)</userrating>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if userrating == None:

                #raise

                userrating = ''

        except:

            userrating = ''



        try:

            votes = re.compile('<votes>(.*?)</votes>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if votes == None:

                #raise

                votes = ''

        except:

            votes = ''



        try:

            aired = re.compile('<aired>(.*?)</aired>',re.MULTILINE|re.DOTALL).findall(item)[0]

            if aired == None:

                #raise

                aired = ''

        except:

            aired = ''



        #try:

        #    xbmcgui.Dialog().textviewer('Informazione: ', item('director')[0].string)

        #except:

        #    pass



        #xbmcgui.Dialog().textviewer('Informazione:', name)



        try:

            if name > '' and url == '' and not utube > '' and not utubelive > '':

                addLink(name.encode('utf-8', 'ignore'),'None','',thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

            elif name > '' and url == None and not utube > '' and not utubelive > '':

                addLink(name.encode('utf-8', 'ignore'),'None','',thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

            elif category == 'Adult' and url.find('redecanais') >= 0 and url.find('m3u8') >= 0:

                addDir2(name.encode('utf-8', 'ignore'),url,10,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif category == 'Adult' and url.find('canaismax') >= 0:

                addDir2(name.encode('utf-8', 'ignore'),url,10,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif url.find('canaismax') >= 0 and url.find('page') >= 0:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif url.find('ultracine_page') >= 0 and not len(url2) >1:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif url.find('streamtape.com') >= 0 and not len(url2) >1:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif url.find('netcine2_page') >= 0 and not len(url2) >1:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif url.find('series_canaismax') >= 0 and not len(url2) >1:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif url.find('filmes_canaismax') >= 0 and not len(url2) >1:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif utube > '' and len(utube) == 11:

                link_youtube = 'plugin://plugin.video.youtube/play/?video_id='+utube

                addLink(name.encode('utf-8', 'ignore'), link_youtube,subtitle,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

            elif utubelive > '' and len(utubelive) == 11:

                link_live = 'https://www.youtube.com/watch?v='+utubelive

                addDir2(name.encode('utf-8', 'ignore'),link_live,17,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif len(externallink)>0:

                addDir(name.encode('utf-8', 'ignore'),resolver(url),1,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

            ##Multilink

            elif len(url2) >1 and len(subtitle2) >1 and re.search(playlist_command,url,re.IGNORECASE):

                name_resolve = name+'[COLOR red] ('+str(len(url2))+' itens)[/COLOR]'

                addDir2(name_resolve.encode('utf-8', 'ignore'),str(url2).replace(',','||').replace('$'+playlist_command+'','#'+playlist_command+''),11,str(subtitle2).replace(',','||'),thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif len(url2) >1 and re.search(playlist_command,url,re.IGNORECASE):

                name_resolve = name+'[COLOR red] ('+str(len(url2))+' itens)[/COLOR]'

                addDir2(name_resolve.encode('utf-8', 'ignore'),str(url2).replace(',','||').replace('$'+playlist_command+'','#'+playlist_command+''),11,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

                #addLink(name.encode('utf-8', 'ignore'),resolver(url),subtitle,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

            elif category == 'Adult':

                addDir2(name.encode('utf-8', 'ignore'),url,10,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            elif resolver(url).startswith('plugin://plugin.video.youtube/playlist') == True or resolver(url).startswith('plugin://plugin.video.youtube/channel') == True or resolver(url).startswith('plugin://plugin.video.youtube/user') == True or resolver(url).startswith('Plugin://plugin.video.youtube/playlist') == True:

                addDir(name.encode('utf-8', 'ignore'),resolver(url),6,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

            elif pesquisa:

                addDir2(name.encode('utf-8', 'ignore'),url,16,subtitle,thumbnail,fanArt,desc.encode('utf-8'),genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,False)

            else:

                #xbmcgui.Dialog().textviewer('Informazione:', 'ok')

                #addLink(name.encode('utf-8', 'ignore'),resolver(url, name, thumbnail).encode('utf-8'),subtitle,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

                addLink(name.encode('utf-8', 'ignore'),resolver(url),subtitle,thumbnail,fanArt,desc,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired)

        except:

            notify('[COLOR red]Errore nel caricare la lista![/COLOR]')



def adult(name, url, iconimage, description, subtitle):
    try:
        Path = dlpXbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    except:
        Path = dlpXbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    arquivo = os.path.join(Path, "password.txt")
    exists = os.path.isfile(arquivo)
    keyboard = xbmcaddon.Addon().getSetting("keyboard")
    if exists == False:
        parental_password()
        xbmc.sleep(10)
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        if int(keyboard) == 0:

            ps = dialog.numeric(0, 'Immetti la password corrente:', bHiddenInput=True)

        else:

            ps = dialog.input('Immetti la password corrente:', option=xbmcgui.ALPHANUM_HIDE_INPUT)

        if ps == p_file_b64_decode:

            urlresolver = resolver(url)

            #if urlresolver.startswith("plugin://") and not 'elementum' in str(urlresolver):
            #    xbmc.executebuiltin('RunPlugin(' + urlresolver + ')')
            #elif urlresolver.startswith('plugin://plugin.video.youtube/playlist') == True or urlresolver.startswith('plugin://plugin.video.youtube/channel') == True or urlresolver.startswith('plugin://plugin.video.youtube/user') == True or urlresolver.startswith('Plugin://plugin.video.youtube/playlist') == True:

            if urlresolver.startswith('plugin://plugin.video.youtube/playlist') == True or urlresolver.startswith('plugin://plugin.video.youtube/channel') == True or urlresolver.startswith('plugin://plugin.video.youtube/user') == True or urlresolver.startswith('Plugin://plugin.video.youtube/playlist') == True:
                xbmc.executebuiltin("ActivateWindow(10025," + urlresolver + ",return)")
            else:

                li = xbmcgui.ListItem(name, path=urlresolver)
                li.setArt({"icon": iconimage, "thumb": iconimage})
                li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
                if subtitle > '':
                    li.setSubtitles([subtitle])
                xbmc.Player().play(item=urlresolver, listitem=li)

        else:
            xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Password non valida!, Se non modificata, utilizza la password predefinita')
    else:

        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        if int(keyboard) == 0:
            ps = dialog.numeric(0, 'Inserire la password corrente:', bHiddenInput=True)

        else:
            ps = dialog.input('Immetti la password corrente:', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if ps == p_file_b64_decode:
            urlresolver = resolver(url)
            #if urlresolver.startswith("plugin://") and not 'elementum' in str(urlresolver):
            #    xbmc.executebuiltin('RunPlugin(' + urlresolver + ')')
            #elif urlresolver.startswith('plugin://plugin.video.youtube/playlist') == True or urlresolver.startswith('plugin://plugin.video.youtube/channel') == True or urlresolver.startswith('plugin://plugin.video.youtube/user') == True or urlresolver.startswith('Plugin://plugin.video.youtube/playlist') == True:
            if urlresolver.startswith('plugin://plugin.video.youtube/playlist') == True or urlresolver.startswith('plugin://plugin.video.youtube/channel') == True or urlresolver.startswith('plugin://plugin.video.youtube/user') == True or urlresolver.startswith('Plugin://plugin.video.youtube/playlist') == True:
                xbmc.executebuiltin("ActivateWindow(10025," + urlresolver + ",return)")
            else:

                li = xbmcgui.ListItem(name, path=urlresolver)

                li.setArt({"icon": iconimage, "thumb": iconimage})

                li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })

                if subtitle > '':

                    li.setSubtitles([subtitle])

                xbmc.Player().play(item=urlresolver, listitem=li)

        else:

            xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Password non valida!, Se non modificata, utilizza la password predefinita')



def playlist(name, url, iconimage, description, subtitle):
    playlist_command1 = playlist_command
    dialog = xbmcgui.Dialog()
    links = re.compile('<link>([\s\S]*?)#'+playlist_command1+'', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
    names = re.compile('#'+playlist_command1+'=([\s\S]*?)</link>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
    names2 = []
    subtitles = re.compile('<subtitle>([\s\S]*?)</subtitle>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(subtitle)

    for name in names:
        myname = name.replace('+', ' ')
        names2.append(myname)

    if links !=[] and names2 !=[]:
        index = dialog.select(dialog_playlist, names2)

        if index >= 0:
            playname=names2[index]
            if playname > '':
                playname1 = playname
            else:
                playname1 = 'Desconhecido'
            playlink=links[index]
            if subtitles !=[]:
                playsub=subtitles[index]
            else:
                playsub = ''
            urlresolver = resolver(playlink)

            #if urlresolver.startswith("plugin://") and not 'elementum' in str(urlresolver):

            #    xbmc.executebuiltin('RunPlugin(' + urlresolver + ')')

            #elif urlresolver.startswith('plugin://plugin.video.youtube/playlist') == True or urlresolver.startswith('plugin://plugin.video.youtube/channel') == True or urlresolver.startswith('plugin://plugin.video.youtube/user') == True or urlresolver.startswith('Plugin://plugin.video.youtube/playlist') == True:

            if urlresolver.startswith('plugin://plugin.video.youtube/playlist') == True or urlresolver.startswith('plugin://plugin.video.youtube/channel') == True or urlresolver.startswith('plugin://plugin.video.youtube/user') == True or urlresolver.startswith('Plugin://plugin.video.youtube/playlist') == True:
                xbmc.executebuiltin("ActivateWindow(10025," + urlresolver + ",return)")
            else:
                li = xbmcgui.ListItem(playname1, path=urlresolver)
                li.setArt({"icon": iconimage, "thumb": iconimage})
                li.setInfo(type='video', infoLabels={'Title': playname1, 'plot': description })
                if subtitle > '':
                    li.setSubtitles([playsub])
                xbmc.Player().play(item=urlresolver, listitem=li)







def individual_player(name, url, iconimage, description, subtitle):
    urlresolver = resolver(url)
    #if urlresolver.startswith("plugin://") and not 'elementum' in str(urlresolver):

    #    xbmc.executebuiltin('RunPlugin(' + urlresolver + ')')

    #else:
    li = xbmcgui.ListItem(name, path=urlresolver)
    li.setArt({"icon": iconimage, "thumb": iconimage})
    li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
    if subtitle > '':
        li.setSubtitles([subtitle])
    xbmc.Player().play(item=urlresolver, listitem=li)





def m3u8_player(name, url, iconimage, description, subtitle):
    #if url.startswith("plugin://") and not 'elementum' in str(url):

    #    xbmc.executebuiltin('RunPlugin(' + url + ')')

    #else:
    li = xbmcgui.ListItem(name, path=url)
    li.setArt({"icon": iconimage, "thumb": iconimage})
    li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
    if subtitle > '':
        li.setSubtitles([subtitle])
    try:
        xbmc.Player().play(item=url, listitem=li)
    except:
        import xbmc
        xbmc.Player().play(item=url, listitem=li)





def ascii(string):
    if isinstance(string, basestring):
        if isinstance(string, unicode):
           string = string.encode('ascii', 'ignore')
    return string

def uni(string, encoding = 'utf-8'):
    if isinstance(string, basestring):
        if not isinstance(string, unicode):
            string = unicode(string, encoding, 'ignore')
    return string

def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

def sendJSON(command):
    data = ''
    try:
        data = dlpXbmc.executeJSONRPC(uni(command))
    except UnicodeEncodeError:
        data = dlpXbmc.executeJSONRPC(ascii(command))

    return uni(data)





def pluginquerybyJSON(url):
    json_query = uni('{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":["thumbnail","title","year","dateadded","fanart","rating","season","episode","studio"]},"id":1}') %url
    json_folder_detail = json.loads(sendJSON(json_query))
    for i in json_folder_detail['result']['files'] :
        url = i['file']
        name = removeNonAscii(i['label'])
        thumbnail = removeNonAscii(i['thumbnail'])
        try:

            fanart = removeNonAscii(i['fanart'])

        except Exception:

            fanart = ''

        try:

            date = i['year']

        except Exception:

            date = ''

        try:

            episode = i['episode']

            season = i['season']

            if episode == -1 or season == -1:

                description = ''

            else:

                description = '[COLOR yellow] S' + str(season)+'[/COLOR][COLOR hotpink] E' + str(episode) +'[/COLOR]'

        except Exception:

            description = ''

        try:

            studio = i['studio']

            if studio:

                description += '\n Studio:[COLOR steelblue] ' + studio[0] + '[/COLOR]'

        except Exception:

            studio = ''


        desc = description+'\n\nDate: '+str(date)

        if i['filetype'] == 'file':

            #addLink(url,name,thumbnail,fanart,description,'',date,'',None,'',total=len(json_folder_detail['result']['files']))

            addLink(name.encode('utf-8', 'ignore'),url.encode('utf-8'),'',thumbnail,fanart,desc,'','','','','','','','','','','','','','','','')

            #xbmc.executebuiltin("Container.SetViewMode(500)")



        else:

            #addDir(name,url,53,thumbnail,fanart,description,'',date,'')

            addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),6,iconimage,fanart,desc,'','','','','','','','','','','','','','','','')

            #xbmc.executebuiltin("Container.SetViewMode(500)")



def youtube_live(url):

    data = getRequest2(url, 'https://www.youtube.com/')

    #print(data)

    match = re.compile('"hlsManifestUrl.+?"(.+?).m3u8', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

    if match !=[]:

        stream = match[0].replace(':\\"https:', 'https:').replace('\/', '/').replace('\n', '')+'.m3u8|Referer=https://www.youtube.com/|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'

        #print(stream)

        return stream

    else:

        stream = ''

        return stream





def youtube_live_player(name, url, iconimage, description, subtitle):
    li = xbmcgui.ListItem(name, path=youtube_live(url))
    li.setArt({"icon": iconimage, "thumb": iconimage})
    li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
    if subtitle > '':
        li.setSubtitles([subtitle])
    xbmc.Player().play(item=youtube_live(url), listitem=li)



def youtube(url):
    plugin_url = url
    xbmc.executebuiltin("ActivateWindow(10025," + plugin_url + ",return)")

def youtube_resolver(url):
    link_youtube = url
    if link_youtube.startswith('https://www.youtube.com/watch?v') == True or link_youtube.startswith('https://youtube.com/watch?v') == True:
        get_id1 = re.compile('v=(.+?)&', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        get_id2 = re.compile('v=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        if get_id1 !=[]:
            #print('tem')
            id_video = get_id1[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/play/?video_id='+id_video
        elif get_id2 !=[]:
            #print('tem2')
            id_video = get_id2[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/play/?video_id='+id_video
        else:
            resolve = ''
    elif link_youtube.startswith('https://www.youtube.com/playlist?') == True or link_youtube.startswith('https://youtube.com/playlist?') == True:
        get_id1 = re.compile('list=(.+?)&', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        get_id2 = re.compile('list=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        if get_id1 !=[]:
            #print('tem')
            id_video = get_id1[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/playlist/'+id_video+'/?page=0'
        elif get_id2 !=[]:
            #print('tem2')
            id_video = get_id2[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/playlist/'+id_video+'/?page=0'
        else:
            resolve = ''
    elif link_youtube.startswith('https://www.youtube.com/channel') == True or link_youtube.startswith('https://youtube.com/channel') == True:
        get_id1 = re.compile('channel/(.+?)&', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        get_id2 = re.compile('channel/(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        if get_id1 !=[]:
            #print('tem')
            id_video = get_id1[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/channel/'+id_video+'/'
        elif get_id2 !=[]:
            #print('tem2')
            id_video = get_id2[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/channel/'+id_video+'/'
        else:
            resolve = ''
    elif link_youtube.startswith('https://www.youtube.com/user') == True or link_youtube.startswith('https://youtube.com/user') == True:
        get_id1 = re.compile('user/(.+?)&', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        get_id2 = re.compile('user/(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link_youtube)
        if get_id1 !=[]:
            #print('tem')
            id_video = get_id1[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/user/'+id_video+'/'
        elif get_id2 !=[]:
            #print('tem2')
            id_video = get_id2[0]
            #print(id)
            resolve = 'plugin://plugin.video.youtube/user/'+id_video+'/'
        else:
            resolve = ''

    else:
        resolve = ''
    return resolve


def youtube_restore(url):

    if url.find('/?video_id=') >= 0:

        find_id = re.compile('/?video_id=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)

        normal_url = 'https://www.youtube.com/watch?v='+str(find_id[0])

    elif url.find('youtube/playlist/') >= 0:

        find_id = re.compile('/playlist/(.+?)/', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)

        normal_url = 'https://www.youtube.com/playlist?list='+str(find_id[0])

    else:

        normal_url = ''

    return normal_url





def data_youtube(url, ref):

    try:

        try:

            import cookielib

        except ImportError:

            import http.cookiejar as cookielib

        try:

            import urllib2

        except ImportError:

            import urllib.request as urllib2

        if ref > '':

            ref2 = ref

        else:

            ref2 = url

        cj = cookielib.CookieJar()

        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

        opener.addheaders=[('Accept-Language', 'en-US,en;q=0.9;q=0.8'),('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'), ('Referer', ref2)]

        data = opener.open(url).read()

        response = data.decode('utf-8')

        return response

    except:

        #pass

        response = ''

        return response





def getPlaylistLinksYoutube(url):

    try:

        sourceCode = data_youtube(youtube_restore(url), '')

    except:

        sourceCode = ''

    ytb_re = re.compile('url":"https://i.ytimg.com/vi/(.+?)/hqdefault.+?"width":.+?,"height":.+?}]},"title".+?"text":"(.+?)"}],', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(sourceCode)

    for video_id,name in ytb_re:

        original_name = str(name).replace(r"\u0026","&").replace('\\', '')

        thumbnail = "https://img.youtube.com/vi/%s/0.jpg" % video_id

        fanart = "https://i.ytimg.com/vi/%s/hqdefault.jpg" % video_id

        plugin_url = 'plugin://plugin.video.youtube/play/?video_id='+video_id

        urlfinal = str(plugin_url)

        description = ''

        addLink(original_name.encode('utf-8', 'ignore'),urlfinal,'',str(thumbnail),str(fanart),description,'','','','','','','','','','','','','','','','')





def canaismax(url):

    try:

        page = str(re.compile('canaismax_page=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0])

        data = getRequest2(page,'')

        source = re.compile('source.+?"(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

        source2 = re.compile('var.+?url.+?=.+?"(.+?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

        if source2 !=[]:

            link = source2[0].replace('\n','').replace('\r','')

            if '.m3u8' in str(link):

                stream = str(link)

            else:

                stream = ''

        elif source !=[]:

            link = source[0].replace('\n','').replace('\r','')

            if '.m3u8' in str(link):

                stream = str(link)

            else:

                stream = ''

        else:

            stream = ''

        return stream

    except:

        stream = ''

        return stream





def netcine2(url):

    try:

        page = str(re.compile('netcine2_page=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0])

        data = getRequest2(page,'')

        source = re.compile('source.+?"(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

        if source !=[]:

            link = source[0].replace('\n','').replace('\r','')

        else:

            link = ''

        return link

    except:

        link = ''

        return link





def ultracine(url):

    try:

        page = str(re.compile('ultracine_page=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0])

        data = getRequest2(page,'')

        source = re.compile('.log.+?"(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

        if source !=[]:

            link = source[0].replace('\n','').replace('\r','')

        else:

            link = ''

        return link

    except:

        link = ''

        return link





def streamtape(url):

    correct_url = url.replace('streamtape.com/v/', 'streamtape.com/e/')

    data = getRequest2(correct_url,'')

    link_part1_re = re.compile('videolink.+?style="display:none;">(.*?)&token=').findall(data)

    link_part2_re = re.compile("<script>.+?token=(.*?)'.+?</script>").findall(data)

    if link_part1_re !=[] and link_part2_re !=[]:

        #link = 'https:'+link_re[0]+'&stream=1'

        #link = 'https:'+link_part1_re[0]+'&token='+link_part2_re[0]

        link = 'https:'+link_part1_re[0]+'&token='+link_part2_re[0]+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'

    else:

        link = ''

    return link





def series_canaismax(url):

    try:

        page = re.compile('series_canaismax=(.+?)&idioma=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)

        link = page[0][0]

        idioma = page[0][1]

        if 'leg' in idioma or 'Leg' in idioma or 'LEG' in idioma:

            data = getRequest2(link,'')

            tags = re.compile('javascript.+?data-id="(.+?)".+?data-episodio="(.+?)".+?data-player="(.+?)".+?<i>(.+?)</i>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

            tags2 = []

            for id,episodio,player,lang in tags:

                if 'LEG' in lang:

                    tags2.append((id,episodio,player))

            if tags2 !=[]:

                data_id = tags2[0][0]

                data_episodio = tags2[0][1]

                data_player = tags2[0][2]

                data2 = getRequest2('https://canaismax.com/embed/'+data_id+'/'+data_episodio+'/'+data_player,'')

                source = str(re.compile('source.+?"(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)[0])+'|Referer=https://canaismax.com/'

            else:

                source = ''

        elif 'dub' in idioma or 'Dub' in idioma or 'DUB' in idioma:

            data = getRequest2(link,'')

            tags = re.compile('javascript.+?data-id="(.+?)".+?data-episodio="(.+?)".+?data-player="(.+?)".+?<i>(.+?)</i>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

            tags2 = []

            for id,episodio,player,lang in tags:

                if 'DUB' in lang:

                    tags2.append((id,episodio,player))

            if tags2 !=[]:

                data_id = tags2[0][0]

                data_episodio = tags2[0][1]

                data_player = tags2[0][2]

                data2 = getRequest2('https://canaismax.com/embed/'+data_id+'/'+data_episodio+'/'+data_player,'')

                source = str(re.compile('source.+?"(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)[0])+'|Referer=https://canaismax.com/'

            else:

                source = ''

        else:

            source = ''

        return source

    except:

        source = ''

        return source





def filmes_canaismax(url):

    try:

        page = re.compile('filmes_canaismax=(.+?)&idioma=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)

        link = page[0][0]

        idioma = page[0][1]

        if 'leg' in idioma or 'Leg' in idioma or 'LEG' in idioma:

            data = getRequest2(link,'')

            tags = re.compile('javascript.+?data-id="(.+?)".+?data-player="(.+?)".+?<i>(.+?)</i>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

            tags2 = []

            for id,player,lang in tags:

                if 'LEG' in lang:

                    tags2.append((id,player))

            if tags2 !=[]:

                data_id = tags2[0][0]

                data_player = tags2[0][1]

                data2 = getRequest2('https://canaismax.com/embed/'+data_id+'/'+data_player,'')

                source = str(re.compile('source.+?"(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)[0])+'|Referer=https://canaismax.com/'

            else:

                source = ''

        elif 'dub' in idioma or 'Dub' in idioma or 'DUB' in idioma:

            data = getRequest2(link,'')

            tags = re.compile('javascript.+?data-id="(.+?)".+?data-player="(.+?)".+?<i>(.+?)</i>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

            tags2 = []

            for id,player,lang in tags:

                if 'DUB' in lang:

                    tags2.append((id,player))

            if tags2 !=[]:

                data_id = tags2[0][0]

                data_player = tags2[0][1]

                data2 = getRequest2('https://canaismax.com/embed/'+data_id+'/'+data_player,'')

                source = str(re.compile('source.+?"(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)[0])+'|Referer=https://canaismax.com/'

            else:

                source = ''

        else:

            source = ''

        return source

    except:

        source = ''

        return source



def resolver(link):

    link_decoded = link

    try:
        if not link_decoded.startswith("plugin://plugin") and link_decoded.startswith('https://drive.google.com') == True:
            #print('verdadeiro')
            resolved = link_decoded.replace('http','plugin://plugin.video.gdrive?mode=streamURL&amp;url=http')
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.startswith('http://drive.google.com') == True:
            #print('verdadeiro')
            resolved = link_decoded.replace('http','plugin://plugin.video.gdrive?mode=streamURL&amp;url=http')
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('streamtape.com') >= 0:
            link = streamtape(link_decoded)
            resolved = link
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('ultracine_page') >= 0:
            link = ultracine(link_decoded)
            resolved = link
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('netcine2_page') >= 0:
            link = netcine2(link_decoded)
            resolved = link
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('series_canaismax') >= 0:
            link_corrigido = link_decoded.replace('idioma;', 'idioma')
            link = series_canaismax(link_corrigido)
            resolved = link
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('filmes_canaismax') >= 0:
            link_corrigido = link_decoded.replace('idioma;', 'idioma')
            link = filmes_canaismax(link_corrigido)
            resolved = link
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('eu-central-1.edge.mycdn.live') >= 0:
            #print('verdadeiro')
            resolved = link_decoded
            #print(resolved)

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('canaismax_page') >= 0:
            stream = canaismax(link_decoded)
            resolved = stream+'|Referer=https://canaismax.com/|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.startswith('https://youtube.com/') == True or link_decoded.startswith('https://www.youtube.com/') == True:

            try:
                resultado = youtube_resolver(link_decoded)
                if resultado==None:
                    #print('vazio')
                    resolved = ''

                else:
                    resolved = resultado

            except:
                resolved = ''

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.startswith('https://photos.app') == True:

            try:
                data = getRequest2(link_decoded, 'https://photos.google.com/')
                result = re.compile('<meta property="og:video" content="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)

                if result !=[]:
                    resolved = result[0].replace('-m18','-m22')

                else:
                    resolved = ''

            except:
                resolved = ''

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.startswith('magnet:?xt=') == True:
            resolved = 'plugin://plugin.video.elementum/play?uri='+link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.torrent') >= 0:
            resolved = 'plugin://plugin.video.elementum/play?uri='+link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.mp4') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.mkv') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.wmv') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.wma') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.avi') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.mp3') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.ac3') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin") and link_decoded.find('.rmvb') >= 0 and not link_decoded.startswith('magnet:?xt=') == True and not link_decoded.find('.torrent') >= 0:
            resolved = link_decoded

        elif not link_decoded.startswith("plugin://plugin"):
            resolved = link_decoded

        elif link_decoded.startswith("plugin://plugin"):
            resolved = link_decoded

        return resolved

    except:

        resolved = ''
        return resolved
        #pass
        #notify('[COLOR red]Link risorsa non trovata![/COLOR]')



def urlencode(url):     
    import binascii, zlib    
    url = binascii.hexlify(zlib.compress(url.encode('utf-8')))
    return url

    

def urlencode(subtitle):     
    import binascii, zlib    
    subtitle = binascii.hexlify(zlib.compress(subtitle.encode('utf-8')))
    return subtitle

    

def url_decode(url):    
    import binascii, zlib      
    url = zlib.decompress(binascii.unhexlify(url)).decode('utf-8')
    return url



def url_decode(subtitle):
    import binascii, zlib      
    subtitle = zlib.decompress(binascii.unhexlify(subtitle)).decode('utf-8')
    return subtitle



def getFavorites():
    import binascii, zlib 

    try:
        try:
            items = json.loads(open(favorites).read())
        except:
            items = ''

        total = len(items)

        if int(total) > 0:
            for i in items:
                name = i[0]
                url = i[1]

                try:
                    urldecode = zlib.decompress(binascii.unhexlify(url))

                except:
                    urldecode = url

                try:
                    url2 = urldecode.decode('utf-8')

                except:
                    url2 = urldecode

                mode = i[2]
                subtitle = i[3]

                try:
                    subtitledecode = zlib.decompress(binascii.unhexlify(subtitle))

                except:
                    subtitledecode = subtitle

                try:

                    sub2 = subtitledecode.decode('utf-8')

                except:

                    sub2 = subtitledecode

                iconimage = i[4]

                try:
                    fanArt = i[5]

                    if fanArt == None:
                        raise

                except:

                    if addon.getSetting('use_thumb') == "true":
                        fanArt = iconimage

                    else:
                        fanArt = fanart

                description = i[6]



                if mode == 0:
                    try:
                        #addLink(name.encode('utf-8', 'ignore'),url2,sub2,iconimage,fanArt,description.encode('utf-8'),'','','','','','','','','','','','','','','','')
                        addLink(name.encode('utf-8', 'ignore'),url2,sub2,iconimage,fanArt,description.encode('utf-8'),'','','','','','','','','','','','','','','','')

                    except:
                        pass

                elif mode == 11 or mode == 16 or mode == 17 or mode == 18:

                    try:
                        addDir2(str(name).encode('utf-8', 'ignore'),url2,mode,sub2,iconimage,fanArt,description.encode('utf-8'),'','','','','','','','','','','','','','','','',False)

                    except:
                        pass

                elif mode > 0 and mode < 7:

                    try:

                        addDir(name.encode('utf-8', 'ignore'),url2,mode,iconimage,fanArt,description.encode('utf-8'),'','','','','','','','','','','','','','','','')

                    except:

                        pass

                else:

                    try:

                        addDir2(name.encode('utf-8', 'ignore'),url2,mode,sub2,iconimage,fanArt,description.encode('utf-8'),'','','','','','','','','','','','','','','','')

                    except:

                        pass

                xbmcplugin.setContent(addon_handle, 'movies')

                xbmcplugin.endOfDirectory(addon_handle)

        else:

            xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','Nessun elemento aggiunto ai preferiti')

    except:

        pass



def addFavorite(name,url,fav_mode,subtitle,iconimage,fanart,description):
    favList = []
    if os.path.exists(favorites)==False:
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        addon_data_path = dlpXbmc.translatePath(os.path.join('special://home/userdata/addon_data', addonID))
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        favList.append((name,url,fav_mode,subtitle,iconimage,fanart,description))
        a = open(favorites, "w")
        a.write(json.dumps(favList))
        a.close()
        notify('Aggiunto ai preferiti '+__addonname__)
        #xbmc.executebuiltin("dlpXbmc.Container.Refresh")

    else:
        a = open(favorites).read()
        data = json.loads(a)
        data.append((name,url,fav_mode,subtitle,iconimage,fanart,description))
        b = open(favorites, "w")
        b.write(json.dumps(data))
        b.close()
        notify('Aggiunto ai preferiti '+__addonname__)
        #xbmc.executebuiltin("dlpXbmc.Container.Refresh")



def rmFavorite(name):
    data = json.loads(open(favorites).read())
    for index in range(len(data)):
        if data[index][0]==name:
            del data[index]
            b = open(favorites, "w")
            b.write(json.dumps(data))
            b.close()
            break

    notify('Rimuovo dai favoriti '+__addonname__)
    #xbmc.executebuiltin("dlpXbmc.Container.Refresh")


def addDir(name,url,mode,iconimage,fanart,description,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,folder=True):
    if mode == 1:
        if url > '':
            #u=sys.argv[0]+"?url="+urllib.quote_plus(base64.b64encode(url))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
            #u=sys.argv[0]+"?url="+urllib.quote_plus(codecs.encode(base64.b32encode(base64.b16encode(url)), '\x72\x6f\x74\x31\x33'))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
            #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
            #u=sys.argv[0]+"?url="+urllib.quote_plus(base64.b32encode(url.encode('utf-8')))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
            #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
            u=sys.argv[0]+"?url="+urllib.quote_plus(urlencode(url))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)

        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(5)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)

    else:
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
    li=xbmcgui.ListItem(name)

    if folder:
        li.setArt({"icon": "DefaultFolder.png", "thumb": iconimage})

    else:
        li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})

    if date == '':
        date = None

    else:
        description += '\n\nDate: %s' %date

    li.setInfo('video', { 'title': name, 'plot': description })

    try:
        li.setInfo('video', { 'genre': str(genre) })

    except:
        pass

    try:
        li.setInfo('video', { 'dateadded': str(date) })

    except:
        pass

    try:
        li.setInfo('video', { 'credits': str(credits) })

    except:
        pass

    try:
        li.setInfo('video', { 'year': int(year) })

    except:
        pass

    try:
        li.setInfo('video', { 'year': int(year) })

    except:
        pass

    try:
        li.setInfo('video', { 'director': str(director) })

    except:
        pass

    try:
        li.setInfo('video', { 'writer': str(writer) })

    except:
        pass

    try:
        li.setInfo('video', { 'duration': int(duration) })

    except:
        pass

    try:
        li.setInfo('video', { 'premiered': str(premiered) })

    except:
        pass

    try:

        li.setInfo('video', { 'studio': str(studio) })

    except:

        pass

    try:

        li.setInfo('video', { 'mpaa': str(rate) })

    except:

        pass

    try:

        li.setInfo('video', { 'originaltitle': str(originaltitle) })

    except:

        pass

    try:

        li.setInfo('video', { 'country': str(country) })

    except:

        pass

    try:

        li.setInfo('video', { 'rating': float(rating) })

    except:

        pass

    try:

        li.setInfo('video', { 'userrating': int(userrating) })

    except:

        pass

    try:

        li.setInfo('video', { 'votes': str(votes) })

    except:

        pass

    try:

        li.setRating("imdb", float(rating), int(votes), True)

    except:

        pass

    try:

        li.setInfo('video', { 'aired': str(aired) })

    except:

        pass



    if fanart > '':

        li.setProperty('fanart_image', fanart)

    else:

        li.setProperty('fanart_image', ''+home+'/fanart.gif')

    try:

        name_decode = name.decode('utf-8')

    except:

        name_decode = name

    try:

        name_fav = json.dumps(name_decode)

    except:

        name_fav =  name_decode

    try:

        contextMenu = []

        #if favoritos == 'true' and  mode !=4 and mode !=7 and mode !=8 and mode !=9 and mode !=10 and mode !=12 and mode !=15:

            #if name_fav in FAV:

                #contextMenu.append(('Remover dos Favoritos do '+__addonname__,'RunPlugin(%s?mode=14&name=%s)'%(sys.argv[0], urllib.quote_plus(name))))

            #else:

                #fav_params = ('%s?mode=13&name=%s&url=%s&subtitle=%s&iconimage=%s&fanart=%s&description=%s&fav_mode=%s'%(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(urlencode(url)), '', urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(description), str(mode)))

                #contextMenu.append(('Adicionar '+__addonname__,'RunPlugin(%s)' %fav_params))

        contextMenu.append(('Informazione', 'RunPlugin(%s?mode=19&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))

        li.addContextMenuItems(contextMenu)

    except:

        pass

    xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li, isFolder=folder)



def addDir2(name,url,mode,subtitle,iconimage,fanart,description,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,folder=True):
    if mode == 1:
        if url > '':
            u=sys.argv[0]+"?url="+urllib.quote_plus(urlencode(url))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(5)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
    else:
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)+"&iconimage="+urllib.quote_plus(iconimage)+"&subtitle="+urllib.quote_plus(subtitle)+"&description="+urllib.quote_plus(description)

    li=xbmcgui.ListItem(name)

    if folder:
        li.setArt({"icon": "DefaultFolder.png", "thumb": iconimage})
    else:
        li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})

    if date == '':
        date = None

    else:
        description += '\n\nDate: %s' %date

    li.setInfo('video', { 'title': name, 'plot': description })

    try:
        li.setInfo('video', { 'genre': str(genre) })

    except:
        pass

    try:
        li.setInfo('video', { 'dateadded': str(date) })

    except:
        pass

    try:
        li.setInfo('video', { 'credits': str(credits) })

    except:
        pass

    try:
        li.setInfo('video', { 'year': int(year) })

    except:
        pass

    try:

        li.setInfo('video', { 'year': int(year) })

    except:

        pass

    try:

        li.setInfo('video', { 'director': str(director) })

    except:

        pass

    try:

        li.setInfo('video', { 'writer': str(writer) })

    except:

        pass

    try:

        li.setInfo('video', { 'duration': int(duration) })

    except:

        pass

    try:

        li.setInfo('video', { 'premiered': str(premiered) })

    except:

        pass

    try:

        li.setInfo('video', { 'studio': str(studio) })

    except:

        pass

    try:

        li.setInfo('video', { 'mpaa': str(rate) })

    except:

        pass

    try:

        li.setInfo('video', { 'originaltitle': str(originaltitle) })

    except:

        pass

    try:

        li.setInfo('video', { 'country': str(country) })

    except:

        pass

    try:

        li.setInfo('video', { 'rating': float(rating) })

    except:

        pass

    try:

        li.setInfo('video', { 'userrating': int(userrating) })

    except:

        pass

    try:

        li.setInfo('video', { 'votes': str(votes) })

    except:

        pass

    try:

        li.setRating("imdb", float(rating), int(votes), True)

    except:

        pass

    try:

        li.setInfo('video', { 'aired': str(aired) })

    except:

        pass

    if fanart > '':

        li.setProperty('fanart_image', fanart)

    else:

        li.setProperty('fanart_image', ''+home+'/fanart.gif')

    try:

        name_decode = name.decode('utf-8')

    except:

        name_decode = name

    try:

        name_fav = json.dumps(name_decode)

    except:

        name_fav =  name_decode

    try:

        contextMenu = []

        #if favoritos == 'true' and  mode !=4 and mode !=7 and mode !=8 and mode !=9 and mode !=10 and mode !=12 and mode !=15:

            #if name_fav in FAV:

                #contextMenu.append(('Remover dos Favoritos do '+__addonname__,'RunPlugin(%s?mode=14&name=%s)'%(sys.argv[0], urllib.quote_plus(name))))

            #else:

                #fav_params = ('%s?mode=13&name=%s&url=%s&subtitle=%s&iconimage=%s&fanart=%s&description=%s&fav_mode=%s'%(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(urlencode(url)), urllib.quote_plus(urlencode(subtitle)), urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(description), str(mode)))

                #contextMenu.append(('Adicionar '+__addonname__,'RunPlugin(%s)' %fav_params))

        contextMenu.append(('Informazione', 'RunPlugin(%s?mode=19&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))

        li.addContextMenuItems(contextMenu)

    except:

        pass

    xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li, isFolder=folder)



def addLink(name,url,subtitle,iconimage,fanart,description,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,folder=False):

    if date == '':
        date = None

    else:

        description += '\n\nDate: %s' %date

    if iconimage > '':
        thumbnail = iconimage

    else:
        thumbnail = 'DefaultVideo.png'

    li=xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": thumbnail})

    if url.startswith("plugin://plugin.video.f4mTester"):
        li.setProperty('IsPlayable', 'false')

    else:
        li.setProperty('IsPlayable', 'true')

    if fanart > '':
        li.setProperty('fanart_image', fanart)

    else:
        li.setProperty('fanart_image', ''+home+'/fanart.gif')

    try:
        name_fav = json.dumps(name)

    except:
        name_fav = name

    name2_fav = name
    desc_fav = description
    li.setInfo('video', { 'plot': description })

    try:

        li.setInfo('video', { 'genre': str(genre) })

    except:

        pass

    try:
        li.setInfo('video', { 'dateadded': str(date) })

    except:
        pass

    try:
        li.setInfo('video', { 'credits': str(credits) })

    except:
        pass

    try:
        li.setInfo('video', { 'year': int(year) })

    except:
        pass

    try:
        li.setInfo('video', { 'year': int(year) })

    except:
        pass

    try:
        li.setInfo('video', { 'director': str(director) })

    except:
        pass

    try:
        li.setInfo('video', { 'writer': str(writer) })

    except:
        pass

    try:
        li.setInfo('video', { 'duration': int(duration) })

    except:
        pass

    try:

        li.setInfo('video', { 'premiered': str(premiered) })

    except:
        pass

    try:
        li.setInfo('video', { 'studio': str(studio) })

    except:
        pass

    try:

        li.setInfo('video', { 'mpaa': str(rate) })

    except:
        pass

    try:
        li.setInfo('video', { 'originaltitle': str(originaltitle) })

    except:
        pass

    try:
        li.setInfo('video', { 'country': str(country) })

    except:
        pass

    try:
        li.setInfo('video', { 'rating': float(rating) })

    except:
        pass

    try:
        li.setInfo('video', { 'userrating': int(userrating) })

    except:
        pass

    try:
        li.setInfo('video', { 'votes': str(votes) })

    except:
        pass

    try:
        
        li.setRating("imdb", float(rating), int(votes), True)

    except:
        pass

    try:
        
        li.setInfo('video', { 'aired': str(aired) })

    except:
        pass



    if subtitle > '':
        li.setSubtitles([subtitle])

    try:

        name_decode = name.decode('utf-8')

    except:

        name_decode = name

    try:

        name_fav = json.dumps(name_decode)

    except:

        name_fav =  name_decode

    try:

        contextMenu = []

        #if favoritos == 'true':

            #if name_fav in FAV:

                #contextMenu.append(('Remover dos Favoritos do '+__addonname__,'RunPlugin(%s?mode=14&name=%s)'%(sys.argv[0], urllib.quote_plus(name))))

            #else:

                #fav_params = ('%s?mode=13&name=%s&url=%s&subtitle=%s&iconimage=%s&fanart=%s&description=%s&fav_mode=0'%(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(urlencode(url)), urllib.quote_plus(urlencode(subtitle)), urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(description)))

                #contextMenu.append(('Adicionar aos Favoritos do '+__addonname__,'RunPlugin(%s)' %fav_params))

        contextMenu.append(('Informazione', 'RunPlugin(%s?mode=19&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))

        li.addContextMenuItems(contextMenu)

    except:
        pass

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=folder)



def parental_password():
    try:
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        addon_data_path = dlpXbmc.translatePath(os.path.join('special://home/userdata/addon_data', addonID))
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        #Path = dlpXbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
        #arquivo = os.path.join(Path, "password.txt")
        arquivo = os.path.join(addon_data_path, "password.txt")
        exists = os.path.isfile(arquivo)
        if exists == False:
            password = '1234'
            p_encoded = base64.b64encode(password.encode()).decode('utf-8')
            p_file = open(arquivo,'w')
            p_file.write(p_encoded)
            p_file.close()
    except:
        pass

def check_addon():
    try:
        check_file = dlpXbmc.translatePath(home+'/check.txt')
        exists = os.path.isfile(check_file)
        check_addon = addon.getSetting('check_addon')
        #check_file = 'check.txt'
        if exists == True:
            #print('existe')
            fcheck = open(check_file,'r+')
            elementum = addon.getSetting('elementum')
            youtube = addon.getSetting('youtube')
            if fcheck and fcheck.read() == '1' and check_addon == 'true':
                #print('valor 1')
                fcheck.close()
                link = getRequest2('https://raw.githubusercontent.com/zoreu/zoreu.github.io/master/kodi/verificar_addons_matrix.txt','').replace('\n','').replace('\r','')
                match = re.compile('addon_name="(.+?)".+?ddon_id="(.+?)".+?ir="(.+?)".+?rl_zip="(.+?)".+?escription="(.+?)"').findall(link)
                for addon_name,addon_id,directory,url_zip,description in match:
                    if addon_id == 'plugin.video.elementum' and elementum == 'false':
                        pass
                    elif addon_id == 'script.module.six' and youtube == 'false':
                        pass
                    elif addon_id == 'plugin.video.youtube' and youtube == 'false':
                        pass
                    else:
                        existe = dlpXbmc.translatePath(directory)
                        #print('Path dir:'+existe)
                        if os.path.exists(existe)==False:
                            install_wizard(addon_name,addon_id,url_zip,directory,description)
                            if addon_id == 'plugin.video.elementum':
                                xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','CHIUDI KODI E APRI DI NUOVO PER ATTIVARE ELEMENTUM')
                        else:
                            pass
        elif check_addon == 'true':
            #print('nao existe')
            fcheck = open(check_file,'w')
            fcheck.write('1')
            fcheck.close()
            xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','CHIUDI KODI E APRI DI NUOVO PER AGGIORNARE')
    except:
        pass


def install_wizard(name,addon_id,url,directory,description):
    try:
        import downloader
        import extract
        import ntpath
        path = dlpXbmc.translatePath(os.path.join('special://','home/','addons', 'packages'))
        filename = ntpath.basename(url)
        dp = xbmcgui.DialogProgress()
        dp.create("Install addons","Baixando "+name+", por favor aguarde....")
        lib=os.path.join(path, filename)
        try:
            os.remove(lib)
        except:
            pass
        downloader.download(url, lib, dp)
        addonfolder = dlpXbmc.translatePath(os.path.join('special://','home/','addons'))
        xbmc.sleep(100)
        dp.update(0,"Instalando "+name+", Por Favor Espere")
        try:
            xbmc.executebuiltin("Extract("+lib+","+addonfolder+")")
        except:
            extract.all(lib,addonfolder,dp)
        #############
        #time.sleep(2)
        xbmc.sleep(100)
        xbmc.executebuiltin("dlpXbmc.UpdateLocalAddons()")
        notify(name+' Instalado com Sucesso!')
        import database
        database.enable_addon(addon_id)
        if addon_id == 'plugin.video.elementum':
            database.enable_addon('repository.elementum')
        #xbmc.executebuiltin("dlpXbmc.Container.Refresh()")
        xbmc.executebuiltin("dlpXbmc.Container.Update()")
        #xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]',''+name+' installato, chiudi e apri Kodi nuovamente')
    except:
        notify('Errore nel completamento')

def time_convert(timestamp):
    try:
        if timestamp > '':
            dt_object = datetime.fromtimestamp(int(timestamp))
            time_br = dt_object.strftime('%d/%m/%Y às %H:%M:%S')
            return str(time_br)
        else:
            valor = ''
            return valor
    except:
        valor = ''
        return valor

def SetView(name):
    if name == 'Wall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(500)')
        except:
            pass
    if name == 'List':
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except:
            pass
    if name == 'Poster':
        try:
            xbmc.executebuiltin('Container.SetViewMode(51)')
        except:

            pass

    if name == 'Shift':
        try:
            xbmc.executebuiltin('Container.SetViewMode(53)')
        except:
            pass
    if name == 'InfoWall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(54)')
        except:
            pass

    if name == 'WideList':

        try:

            xbmc.executebuiltin('Container.SetViewMode(55)')

        except:

            pass

    if name == 'Fanart':

        try:

            xbmc.executebuiltin('Container.SetViewMode(502)')

        except:

            pass





def get_params():
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')

        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]

        pairsofparams=cleanedparams.split('&')
        param={}

        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')

            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
subtitle=None

try:

    url=urllib.unquote(params["url"])
    #url=urllib.unquote_plus(params["url"]).decode('utf-8')

except:
    pass


try:
    #name=urllib.unquote(params["name"])
    name=urllib.unquote_plus(params["name"])

except:
    pass


try:
    #iconimage=urllib.unquote(params["iconimage"])
    iconimage=urllib.unquote_plus(params["iconimage"])

except:
    pass


try:
    mode=int(params["mode"])

except:
    pass

try:
    #fanart=urllib.unquote(params["fanart"])
    fanart=urllib.unquote_plus(params["fanart"])

except:
    pass


try:
    #description=urllib.unquote(params["description"])
    description=urllib.unquote_plus(params["description"])

except:
    pass

try:
    subtitle=urllib.unquote_plus(params["subtitle"])

except:
    pass

try:
    fav_mode=int(params["fav_mode"])

except:
    pass


if mode==None:    
    xbmcplugin.setContent(addon_handle, 'movies')

    if addon.getSetting('messaggio') == 'true':                
        notify('[COLOR lime]DarkLegion verrà aggiornato ogni volta che sarà possibile. Support by A-Area69[/COLOR]')
        
        check_addon()
        parental_password()
        
        SKindex()
        #SetView('List')

    else:
        check_addon()
        parental_password()
        
        SKindex()        

    SetView('List')



elif mode==1:
    #url = base64.b16decode(base64.b32decode(codecs.decode(url, '\x72\x6f\x74\x31\x33')))
    #url = base64.b64decode(url)
    
    url = url_decode(url)
    try:
        url = url.decode('utf-8')
    except:
        pass
    
    getData(url, fanart)
    xbmcplugin.endOfDirectory(addon_handle)



#elif mode==2:
#    getChannelItems(name,url,fanart)
#    xbmcplugin.endOfDirectory(addon_handle)



#elif mode==3:
#    getSubChannelItems(name,url,fanart)
#    xbmcplugin.endOfDirectory(addon_handle)


#Impostazioni

elif mode==4:
    xbmcaddon.Addon().openSettings()
    xbmc.executebuiltin("dlpXbmc.Container.Refresh()")



#Link Vazio

elif mode==5:
    xbmc.executebuiltin("dlpXbmc.Container.Refresh()")



elif mode==6:
    ytbmode = addon.getSetting('ytbmode')

    if int(ytbmode) == 0:
        pluginquerybyJSON(url)

    elif int(ytbmode) == 1:
        getPlaylistLinksYoutube(url)

    else:
        youtube(url)

    xbmcplugin.endOfDirectory(addon_handle)



elif mode==9:
    xbmcgui.Dialog().ok(titulo_vip, vip_dialogo)
    xbmcaddon.Addon().openSettings()
    xbmcgui.Dialog().ok('[B][COLOR white]AVVISO[/COLOR][/B]','CHIUDI KODI E APRI DI NUOVO PER AGGIORNARE IMPOSTAZIONI')
    xbmc.executebuiltin("dlpXbmc.Container.Refresh()")



elif mode==10:
    adult(name, url, iconimage, description, subtitle)
    xbmcplugin.endOfDirectory(addon_handle)



elif mode==11:
    playlist(name, url, iconimage, description, subtitle)
    xbmcplugin.endOfDirectory(addon_handle)



#elif mode==12:

#    CheckUpdate(True)

#    xbmc.executebuiltin("dlpXbmc.Container.Refresh()")



elif mode==13:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]

    except:
        pass

    addFavorite(name,url,fav_mode,subtitle,iconimage,fanart,description)



elif mode==14:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    rmFavorite(name)


elif mode==15:
    #xbmcplugin.setContent(addon_handle, 'movies')
    getFavorites()
    #xbmcplugin.endOfDirectory(addon_handle)

elif mode==16:
    individual_player(name, url, iconimage, description, subtitle)
    #xbmcplugin.endOfDirectory(addon_handle)

elif mode==17:
    youtube_live_player(name, url, iconimage, description, subtitle)
    #xbmcplugin.endOfDirectory(addon_handle)

elif mode==18:
    m3u8_player(name, url, iconimage, description, subtitle)
    #xbmcplugin.endOfDirectory(addon_handle)


elif mode==19:
    xbmcgui.Dialog().textviewer('Informazione: '+name, description)

elif mode==44:
    
    
    #mostro le webcam dal mondo
    #link da una pagina internet
    listaproposta=crealistanazioni()
    if listaproposta is not None:
        
       tot_nazioni=len(listaproposta)
       if tot_nazioni>0:
            
            for nazione in range(tot_nazioni):
                
                nomeNazione=listaproposta[nazione][1]
                nomeUrl=listaproposta[nazione][0]
              
                
                # passaggio parmetri a addDir3(name,url,mode,subtitle,iconimage,fanart,description,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,folder=True):
                addDir2(nomeNazione,nomeUrl,45,'','','','','','','','','','','','','','','','','','','','',True)
             
       
    xbmcplugin.endOfDirectory(addon_handle)
    
    
elif mode==45:
    
    
    #mostro le webcam dal mondo
    #costruisco il path della città
    
    
    listaproposta=crealistalocalita(url)
    if listaproposta is not None:
        
       tot_localita=len(listaproposta)
       if tot_localita>0:
            
            for citta in range(tot_localita):
                nomeLuogo=listaproposta[citta][2]
                fotoCitta=listaproposta[citta][1]
                nomePath=listaproposta[citta][0]
                descLuogo=listaproposta[citta][3]
                
                # passaggio parmetri a addDir3(name,url,mode,subtitle,iconimage,fanart,description,genre,date,credits,year,director,writer,duration,premiered,studio,rate,originaltitle,country,rating,userrating,votes,aired,folder=True):
                addDir2(nomeLuogo,nomePath,46,'',fotoCitta,fotoCitta,descLuogo,'','','','','','','','','','','','','','','','',False)
             
       
    xbmcplugin.endOfDirectory(addon_handle)
    
elif mode==46:
    
    
    #mostro le webcam dal mondo
    #costruisco il path alla webcam
    
    iconimage=""
    description=""
    subtitle=""
    listaproposta=linkWebCam(url)
    
    if listaproposta is not None:
        
       tot_localita=len(listaproposta)
       if tot_localita>0:
            individual_player(name, listaproposta, iconimage, description, subtitle)
             
       
    xbmcplugin.endOfDirectory(addon_handle)
    