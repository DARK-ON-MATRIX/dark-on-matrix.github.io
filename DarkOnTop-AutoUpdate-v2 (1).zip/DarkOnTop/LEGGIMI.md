# Dark on Top per Android TV, box Android e telefono

App Android nativa (non una pagina web): elenchi veloci, player ExoPlayer,
tastiera di Android per scrivere utente e password.
Il server http://wearelegion.hopto.org è già inserito: basta utente e password.

## Come ottenere l'APK con GitHub (dal telefono va bene)

1. Nel tuo repository GitHub ELIMINA il vecchio zip (DLP-on-TOP-Android.zip):
   la compilazione prende il primo zip che trova, quindi ne deve restare uno solo.
2. "Add file" > "Upload files": carica DLP-on-TOP-TV.zip e premi "Commit changes".
3. Scheda "Actions": aspetta la spunta verde (3-5 minuti).
4. Apri l'esecuzione, in fondo scarica "DLP-on-TOP-APK": dentro c'è app-debug.apk.
5. Installa l'APK. Questa app ha un nome interno diverso dalla precedente,
   quindi la vecchia (com.dlp.ontop) va disinstallata a mano se non ti serve più.

## Telecomando (TV e box)

Elenco:  OK = apri · OK tenuto premuto o Verde = preferito · Rosso = account ·
         Giallo = cerca · Blu = Live/Film/Serie · 1-2-3 = sezioni · Menu = opzioni
Video:   Su/Giù (o CH+/CH-) = cambia canale · OK = info e guida · Verde = preferito ·
         Sinistra/Destra = ±10 secondi (film e serie) · Indietro = torna all'elenco

## Telefono

Tocca per aprire, tieni premuto un titolo per il preferito. Nel video tocca lo
schermo per i pulsanti (✕ ⏮ ★ ⏭).

## Cosa fa

Live, Film, Serie (anche dalle playlist M3U) · gruppi nello stesso ordine della playlist, con il numero a destra · ricerca · preferiti · guida programmi
(Xtream) · più account (Xtream e M3U) · ultimo canale riaperto all'avvio ·
conferma di uscita.

## Non ancora incluso

Guida XMLTV per le playlist M3U · scelta audio/sottotitoli.

## Note

La chiave di firma è dentro il progetto: tieni il repository privato.
