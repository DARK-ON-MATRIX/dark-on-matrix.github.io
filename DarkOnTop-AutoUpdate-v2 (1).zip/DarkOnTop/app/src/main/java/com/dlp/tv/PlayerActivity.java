package com.dlp.tv;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

/** Riproduzione a schermo intero con ExoPlayer. */
public class PlayerActivity extends Activity {
    private SurfaceView surface;
    private ExoPlayer player;
    private TextView info;
    private TextView msg;
    private LinearLayout bar;
    private Button bSeekBack;
    private Button bSeekFwd;
    private List<Item> list;
    private int idx;
    private int retries = 0;
    private boolean wasPlaying = true;
    private final SimpleDateFormat hm = new SimpleDateFormat("HH:mm", Locale.getDefault());

    private final Runnable hideRun = new Runnable() {
        @Override
        public void run() {
            info.setVisibility(View.INVISIBLE);
            bar.setVisibility(View.INVISIBLE);
        }
    };

    private final Runnable retryRun = new Runnable() {
        @Override
        public void run() {
            if (list != null && idx >= 0 && idx < list.size()) startPlayer(list.get(idx).url);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        list = Repo.playlist;
        idx = Repo.index;
        if (list == null || list.isEmpty() || idx < 0 || idx >= list.size()) {
            finish();
            return;
        }
        Ui.immersive(this);
        build();
        play(idx);
    }

    private Button barButton(String t, View.OnClickListener l) {
        Button x = Ui.button(this, t);
        x.setFocusable(false);
        x.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        bar.addView(x, lp);
        return x;
    }

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        surface = new SurfaceView(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleOverlay();
            }
        });

        info = Ui.text(this, "", 18, Ui.TEXT);
        info.setBackgroundColor(0xB0000000);
        info.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(-2, -2);
        ilp.gravity = Gravity.BOTTOM | Gravity.LEFT;
        ilp.setMargins(Ui.dp(this, 24), 0, 0, Ui.dp(this, 24));
        root.addView(info, ilp);

        msg = Ui.text(this, "", 20, Ui.TEXT);
        msg.setGravity(Gravity.CENTER);
        msg.setBackgroundColor(0xB0000000);
        msg.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 12));
        msg.setVisibility(View.GONE);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(-2, -2);
        mlp.gravity = Gravity.CENTER;
        root.addView(msg, mlp);

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setVisibility(View.INVISIBLE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, -2);
        blp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        blp.setMargins(0, 0, Ui.dp(this, 24), Ui.dp(this, 24));
        root.addView(bar, blp);
        barButton("✕", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bSeekBack = barButton("−10s", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seek(-10000);
            }
        });
        barButton("⏮", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                step(-1);
            }
        });
        barButton("★", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fav();
            }
        });
        barButton("⏭", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                step(1);
            }
        });
        bSeekFwd = barButton("+10s", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seek(10000);
            }
        });
        setContentView(root);
    }

    private void ensurePlayer() {
        if (player != null) return;
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setUserAgent(Net.UA)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http))
                .build();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);
        player.setVideoSurfaceView(surface);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int st) {
                if (st == Player.STATE_BUFFERING) {
                    msg.setText("Caricamento...");
                    msg.setVisibility(View.VISIBLE);
                } else if (st == Player.STATE_READY) {
                    msg.setVisibility(View.GONE);
                    retries = 0;
                } else if (st == Player.STATE_ENDED) {
                    if (list.get(idx).type == 3 && idx < list.size() - 1) play(idx + 1);
                }
            }

            @Override
            public void onPlayerError(PlaybackException err) {
                if (retries < 2) {
                    retries++;
                    msg.setText("Riprovo... (" + retries + "/2)");
                    msg.setVisibility(View.VISIBLE);
                    Repo.ui.postDelayed(retryRun, 2500);
                } else {
                    msg.setText("Questo contenuto non si avvia.\nProva un altro (su/giù).");
                    msg.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void startPlayer(String url) {
        ensurePlayer();
        MediaItem.Builder mi = new MediaItem.Builder().setUri(url);
        if (url.contains(".m3u8")) mi.setMimeType(MimeTypes.APPLICATION_M3U8);
        player.setMediaItem(mi.build());
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void play(int i) {
        Repo.ui.removeCallbacks(retryRun);
        idx = i;
        final Item it = list.get(i);
        Repo.nowPlaying = it;
        Repo.index = i;
        if (it.type == 0) Prefs.setLast(this, it.url);
        retries = 0;
        boolean vod = it.type != 0;
        bSeekBack.setVisibility(vod ? View.VISIBLE : View.GONE);
        bSeekFwd.setVisibility(vod ? View.VISIBLE : View.GONE);
        startPlayer(it.url);
        updateInfo();
        showOverlay();
        if (it.type == 0 && Repo.isX && it.sid >= 0) {
            Repo.pool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        Repo.x.shortEpg(it);
                        Repo.ui.post(new Runnable() {
                            @Override
                            public void run() {
                                if (list != null && idx < list.size() && list.get(idx) == it) updateInfo();
                            }
                        });
                    } catch (Exception e) {
                        // guida non disponibile
                    }
                }
            });
        }
    }

    private void updateInfo() {
        Item it = list.get(idx);
        StringBuilder sb = new StringBuilder(it.name);
        Item.Prog n = it.now();
        Item.Prog x = it.next();
        if (n != null) sb.append("\nOra: ").append(n.t).append("  (").append(hm.format(n.s)).append("–").append(hm.format(n.e)).append(")");
        if (x != null) sb.append("\nDopo: ").append(x.t).append("  (").append(hm.format(x.s)).append(")");
        info.setText(sb.toString());
    }

    private void showOverlay() {
        info.setVisibility(View.VISIBLE);
        bar.setVisibility(View.VISIBLE);
        Repo.ui.removeCallbacks(hideRun);
        Repo.ui.postDelayed(hideRun, 4500);
    }

    private void toggleOverlay() {
        if (info.getVisibility() == View.VISIBLE) {
            Repo.ui.removeCallbacks(hideRun);
            hideRun.run();
        } else {
            showOverlay();
        }
    }

    private void step(int d) {
        int n = list.size();
        play(((idx + d) % n + n) % n);
    }

    private void seek(long ms) {
        if (player != null && list.get(idx).type != 0) {
            player.seekTo(Math.max(0, player.getCurrentPosition() + ms));
            showOverlay();
        }
    }

    private void fav() {
        Item it = list.get(idx);
        Repo.toggleFav(this, it);
        Toast.makeText(this, (Repo.favs.contains(it.url) ? "Aggiunto ai preferiti: " : "Tolto dai preferiti: ") + it.name,
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_CHANNEL_UP:
                step(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
                step(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (list.get(idx).type != 0) seek(-10000);
                else showOverlay();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (list.get(idx).type != 0) seek(10000);
                else showOverlay();
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                toggleOverlay();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (player != null) player.setPlayWhenReady(!player.getPlayWhenReady());
                return true;
            case KeyEvent.KEYCODE_PROG_GREEN:
                fav();
                return true;
            case KeyEvent.KEYCODE_PROG_YELLOW:
            case KeyEvent.KEYCODE_INFO:
                showOverlay();
                return true;
            case KeyEvent.KEYCODE_BACK:
                finish();
                return true;
            default:
                return super.onKeyDown(k, e);
        }
    }

    @Override
    protected void onPause() {
        if (player != null) {
            wasPlaying = player.getPlayWhenReady();
            player.setPlayWhenReady(false);
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Ui.immersive(this);
        if (player != null && wasPlaying) player.setPlayWhenReady(true);
    }

    @Override
    protected void onDestroy() {
        Repo.ui.removeCallbacks(retryRun);
        Repo.ui.removeCallbacks(hideRun);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }
}
