package com.dlp.tv;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** Salva gli elenchi scaricati: alla riapertura l'app e' subito pronta. */
final class Cache {
    static void put(Context c, String name, String data) {
        try {
            FileOutputStream o = new FileOutputStream(new File(c.getCacheDir(), name + ".json"));
            o.write(data.getBytes("UTF-8"));
            o.close();
        } catch (Exception e) {
            // senza cache l'app funziona lo stesso
        }
    }

    static String get(Context c, String name, long maxAgeMs) {
        try {
            File f = new File(c.getCacheDir(), name + ".json");
            if (!f.exists() || System.currentTimeMillis() - f.lastModified() > maxAgeMs) return null;
            FileInputStream in = new FileInputStream(f);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return null;
        }
    }
}
