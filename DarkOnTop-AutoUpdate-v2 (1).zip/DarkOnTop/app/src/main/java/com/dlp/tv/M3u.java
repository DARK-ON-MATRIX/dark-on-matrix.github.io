package com.dlp.tv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Legge una playlist M3U/M3U8. */
final class M3u {
    private static final Pattern LOGO = Pattern.compile("tvg-logo=\"([^\"]*)\"");
    private static final Pattern ID = Pattern.compile("tvg-id=\"([^\"]*)\"");
    private static final Pattern GROUP = Pattern.compile("group-title=\"([^\"]*)\"");

    private static final Pattern EP = Pattern.compile(
            "^(.*?)\\s*[-–:._]*\\s*[Ss](\\d{1,2})\\s*[Ee](\\d{1,3})\\s*[-–:._]*\\s*(.*)$");

    private static boolean isVodFile(String u) {
        int q = u.indexOf('?');
        String p = q >= 0 ? u.substring(0, q) : u;
        return p.endsWith(".mp4") || p.endsWith(".mkv") || p.endsWith(".avi")
                || p.endsWith(".mov") || p.endsWith(".wmv") || p.endsWith(".m4v");
    }

    private static final Pattern SERIE_G = Pattern.compile(".*\\b(serie tv|serietv|series|tv series|telefilm|stagione)\\b.*");
    private static final Pattern FILM_G = Pattern.compile(".*\\b(film|films|movie|movies|vod)\\b.*");

    /** 0 = live, 1 = film, 2 = serie (riconosciuti dall'indirizzo o dal nome del gruppo). */
    static int kind(Item it) {
        String u = it.url.toLowerCase(Locale.ROOT);
        if (u.contains("/series/")) return 2;
        if (u.contains("/movie/") || u.contains("/movies/")) return 1;
        if (u.contains("/live/")) return 0;
        String g = it.group.toLowerCase(Locale.ROOT);
        if (SERIE_G.matcher(g).matches()) return 2;
        if (FILM_G.matcher(g).matches()) return 1;
        if (isVodFile(u)) {               // file di film/serie senza altri indizi
            return EP.matcher(it.name).find() ? 2 : 1;
        }
        return 0;
    }

    private static String two(String n) {
        return n.length() < 2 ? "0" + n : n;
    }

    /** Divide la playlist in live, film e serie mantenendo l'ordine originale dei gruppi. */
    static List<List<Item>> split(List<Item> all) {
        List<Item> live = new ArrayList<Item>();
        List<Item> films = new ArrayList<Item>();
        List<Item> series = new ArrayList<Item>();
        Map<String, Item> bySeries = new LinkedHashMap<String, Item>();
        for (Item it : all) {
            int k = kind(it);
            if (k == 0) {
                it.type = 0;
                live.add(it);
            } else if (k == 1) {
                it.type = 1;
                films.add(it);
            } else {
                Matcher m = EP.matcher(it.name);
                if (m.find()) {
                    String title = m.group(1).replaceAll("[\\s\\-–:._]+$", "").trim();
                    if (title.length() == 0) title = it.group;
                    String key = it.group + "|" + title.toLowerCase(Locale.ROOT);
                    Item s = bySeries.get(key);
                    if (s == null) {
                        s = new Item();
                        s.type = 2;
                        s.name = title;
                        s.group = it.group;
                        s.logo = it.logo;
                        s.url = "series:" + key;
                        s.eps = new ArrayList<Item>();
                        bySeries.put(key, s);
                        series.add(s);
                    }
                    String sn = m.group(2);
                    String en = m.group(3);
                    String rest = m.group(4).trim();
                    it.type = 3;
                    it.group = "Stagione " + Integer.parseInt(sn);
                    it.name = "S" + sn + " E" + two(en) + (rest.length() > 0 ? " · " + rest : "");
                    it.ord = Integer.parseInt(sn) * 1000 + Integer.parseInt(en);
                    s.eps.add(it);
                } else {
                    it.type = 3;               // episodio senza numero: si guarda direttamente
                    series.add(it);
                }
            }
        }
        for (Item s : series) {
            if (s.eps != null) {
                Collections.sort(s.eps, new Comparator<Item>() {
                    @Override
                    public int compare(Item a, Item b) {
                        return a.ord - b.ord;
                    }
                });
            }
        }
        List<List<Item>> out = new ArrayList<List<Item>>();
        out.add(live);
        out.add(films);
        out.add(series);
        return out;
    }

    static List<Item> parse(String text) {
        List<Item> out = new ArrayList<Item>();
        String[] lines = text.split("\\r?\\n");
        Item cur = null;
        for (String raw : lines) {
            String l = raw.trim();
            if (l.startsWith("#EXTINF")) {
                cur = new Item();
                int comma = l.indexOf(',');
                cur.name = comma >= 0 ? l.substring(comma + 1).trim() : "Senza nome";
                if (cur.name.length() == 0) cur.name = "Senza nome";
                Matcher m = LOGO.matcher(l);
                if (m.find()) cur.logo = m.group(1);
                m = ID.matcher(l);
                if (m.find()) cur.epgId = m.group(1);
                m = GROUP.matcher(l);
                if (m.find() && m.group(1).length() > 0) cur.group = m.group(1);
            } else if (l.length() > 0 && l.charAt(0) != '#' && cur != null) {
                cur.url = l;
                out.add(cur);
                cur = null;
            }
        }
        return out;
    }
}
