package com.dlp.tv;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Dialoga con un server Xtream Codes. */
final class Xtream {
    private static final String[][] ACT = {
            {"get_live_categories", "get_live_streams"},
            {"get_vod_categories", "get_vod_streams"},
            {"get_series_categories", "get_series"}
    };

    private final String base;
    private final String user;
    private final String pass;
    private final String q;

    Xtream(Account a) {
        String s = a.server.trim();
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://" + s;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        base = s;
        user = a.user.trim();
        pass = a.pass;
        q = base + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass);
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    /** Alcuni server mandano un oggetto invece di una lista: lo trasformiamo in lista. */
    private static JSONArray arr(String json) {
        try {
            String t = json.trim();
            if (t.startsWith("[")) return new JSONArray(t);
            if (t.startsWith("{")) {
                JSONObject o = new JSONObject(t);
                JSONArray a = new JSONArray();
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    Object v = o.opt(it.next());
                    if (v instanceof JSONObject) {
                        JSONObject x = (JSONObject) v;
                        if (x.has("stream_id") || x.has("series_id") || x.has("category_id")) a.put(x);
                    }
                }
                return a.length() > 0 ? a : null;
            }
        } catch (Exception e) {
            // non valido
        }
        return null;
    }

    private static String b64(String t) {
        try {
            return new String(Base64.decode(t, Base64.DEFAULT), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    /** Scarica i dati grezzi: n = 0 live, 1 film, 2 serie. */
    String[] fetch(int n) throws Exception {
        String cats = Net.getRetry(q + "&action=" + ACT[n][0], 90000);
        String st = Net.getRetry(q + "&action=" + ACT[n][1], 120000);
        return new String[]{cats, st};
    }

    List<Item> parse(int n, String catsJson, String streamsJson) throws Exception {
        Map<String, String> names = new HashMap<String, String>();
        JSONArray cats = arr(catsJson);
        List<String> order = new ArrayList<String>();
        if (cats != null) {
            for (int i = 0; i < cats.length(); i++) {
                JSONObject c = cats.getJSONObject(i);
                names.put(c.optString("category_id"), c.optString("category_name"));
                order.add(c.optString("category_name"));
            }
        }
        Repo.catOrder.set(n, order);
        JSONArray st = arr(streamsJson);
        if (st == null) {
            if (n == 0) {
                throw new IOException("accesso non riuscito: controlla utente, password o abbonamento");
            }
            return new ArrayList<Item>();
        }
        List<Item> out = new ArrayList<Item>(st.length());
        String u = enc(user);
        String p = enc(pass);
        for (int i = 0; i < st.length(); i++) {
            JSONObject s = st.getJSONObject(i);
            Item it = new Item();
            it.type = n;
            it.name = s.optString("name", "Senza nome");
            if (it.name.length() == 0) it.name = "Senza nome";
            String g = names.get(s.optString("category_id"));
            it.group = g != null && g.length() > 0 ? g : "Altri";
            it.epgId = s.optString("epg_channel_id");
            if (n == 0) {
                it.logo = s.optString("stream_icon");
                it.sid = s.optInt("stream_id", -1);
                it.url = base + "/live/" + u + "/" + p + "/" + s.optString("stream_id") + ".m3u8";
            } else if (n == 1) {
                it.logo = s.optString("stream_icon");
                String ext = s.optString("container_extension");
                if (ext.length() == 0) ext = "mp4";
                it.url = base + "/movie/" + u + "/" + p + "/" + s.optString("stream_id") + "." + ext;
            } else {
                it.logo = s.optString("cover");
                it.seriesId = s.optInt("series_id", -1);
                it.url = "series:" + it.seriesId;
            }
            out.add(it);
        }
        return out;
    }

    List<Item> episodes(Item series) throws Exception {
        String r = Net.getRetry(q + "&action=get_series_info&series_id=" + series.seriesId, 60000);
        JSONObject o = new JSONObject(r);
        JSONObject eps = o.optJSONObject("episodes");
        List<Item> out = new ArrayList<Item>();
        if (eps == null) return out;
        List<String> seasons = new ArrayList<String>();
        Iterator<String> it = eps.keys();
        while (it.hasNext()) {
            seasons.add(it.next());
        }
        java.util.Collections.sort(seasons, new java.util.Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                try {
                    return Integer.parseInt(a) - Integer.parseInt(b);
                } catch (Exception e) {
                    return a.compareTo(b);
                }
            }
        });
        String u = enc(user);
        String p = enc(pass);
        for (String sn : seasons) {
            JSONArray a = eps.optJSONArray(sn);
            if (a == null) continue;
            for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.getJSONObject(i);
                Item e = new Item();
                e.type = 3;
                e.group = "Stagione " + sn;
                e.name = "S" + sn + " E" + x.optString("episode_num", "?") + " · " + x.optString("title");
                e.logo = series.logo;
                String ext = x.optString("container_extension");
                if (ext.length() == 0) ext = "mp4";
                e.url = base + "/series/" + u + "/" + p + "/" + x.optString("id") + "." + ext;
                out.add(e);
            }
        }
        return out;
    }

    /** Programma in onda e prossimi per un canale live. */
    void shortEpg(Item it) throws Exception {
        if (it.sid < 0) return;
        if (it.epg != null && System.currentTimeMillis() - it.epgAt < 600000) return;
        it.epgAt = System.currentTimeMillis();
        String r = Net.get(q + "&action=get_short_epg&stream_id=" + it.sid + "&limit=3", 15000);
        JSONObject o = new JSONObject(r);
        JSONArray a = o.optJSONArray("epg_listings");
        List<Item.Prog> l = new ArrayList<Item.Prog>();
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                JSONObject p = a.getJSONObject(i);
                l.add(new Item.Prog(p.optLong("start_timestamp") * 1000L,
                        p.optLong("stop_timestamp") * 1000L, b64(p.optString("title"))));
            }
        }
        it.epg = l;
    }
}
