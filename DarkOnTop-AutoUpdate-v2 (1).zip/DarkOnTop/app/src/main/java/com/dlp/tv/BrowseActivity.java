package com.dlp.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Elenco di canali / film / serie con gruppi, ricerca e preferiti. */
public class BrowseActivity extends Activity {
    private int sec = 0;
    private String query = "";
    private final List<String> catKeys = new ArrayList<String>();
    private final List<String> catLabels = new ArrayList<String>();
    private final List<Integer> catCounts = new ArrayList<Integer>();
    private int catIdx = 0;
    private List<Item> shown = new ArrayList<Item>();

    private final Button[] tabs = new Button[3];
    private ListView catList;
    private ListView itemList;
    private LinearLayout statusBox;
    private TextView status;
    private Button retry;
    private TextView countLbl;
    private EditText search;
    private BaseAdapter catAd;
    private BaseAdapter itemAd;
    private int epgPos = -1;

    private final Runnable epgRun = new Runnable() {
        @Override
        public void run() {
            if (!Repo.isX || sec != 0 || epgPos < 0 || epgPos >= shown.size()) return;
            final Item it = shown.get(epgPos);
            if (it.sid < 0) return;
            Repo.pool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        Repo.x.shortEpg(it);
                        Repo.ui.post(new Runnable() {
                            @Override
                            public void run() {
                                if (itemAd != null) itemAd.notifyDataSetChanged();
                            }
                        });
                    } catch (Exception e) {
                        // guida non disponibile
                    }
                }
            });
        }
    };

    private final Runnable searchRun = new Runnable() {
        @Override
        public void run() {
            refreshItems();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Repo.acc == null) {
            startActivity(new Intent(this, AccountsActivity.class));
            finish();
            return;
        }
        Ui.immersive(this);
        build();
        selectSection(0);
        Updater.check(this);
    }

    // ------------------------------------------------------------ grafica

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Bitmap bm = Ui.asset(this, "bg.jpg");
        if (bm != null) bg.setImageBitmap(bm);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View dim = new View(this);
        dim.setBackgroundColor(0xDD0E1317);
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 14);
        col.setPadding(p, p, p, p);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // riga 1: logo, nome account, Account, Esci
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        ImageView banner = new ImageView(this);
        banner.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap bn = Ui.asset(this, "logo.jpg");
        if (bn != null) banner.setImageBitmap(bn);
        r1.addView(banner, new LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56)));
        TextView who = Ui.text(this, "Dark on Top · " + Repo.acc.name, 15, Ui.MUTE);
        who.setPadding(Ui.dp(this, 14), 0, 0, 0);
        r1.addView(who, new LinearLayout.LayoutParams(0, -2, 1f));
        Button refreshBtn = Ui.button(this, "Aggiorna");
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectSection(sec, true);
            }
        });
        r1.addView(refreshBtn);
        Button accBtn = Ui.button(this, "Account");
        accBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAccounts();
            }
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = Ui.dp(this, 8);
        r1.addView(accBtn, alp);
        Button exitBtn = Ui.button(this, "Esci");
        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.confirmExit(BrowseActivity.this);
            }
        });
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-2, -2);
        elp.leftMargin = Ui.dp(this, 8);
        r1.addView(exitBtn, elp);
        col.addView(r1, new LinearLayout.LayoutParams(-1, -2));

        // riga 2: sezioni, ricerca
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        String[] names = {"Live", "Film", "Serie"};
        for (int i = 0; i < 3; i++) {
            final int n = i;
            tabs[i] = Ui.button(this, names[i]);
            tabs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectSection(n);
                }
            });
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
            tlp.rightMargin = Ui.dp(this, 6);
            r2.addView(tabs[i], tlp);
        }
        search = Ui.edit(this, "Cerca per nome");
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString();
                Repo.ui.removeCallbacks(searchRun);
                Repo.ui.postDelayed(searchRun, 300);
            }
        });
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView tv, int action, KeyEvent ev) {
                itemList.requestFocus();
                return true;
            }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, -2, 1f);
        slp.leftMargin = Ui.dp(this, 10);
        r2.addView(search, slp);
        countLbl = Ui.text(this, "", 14, Ui.MUTE);
        countLbl.setPadding(Ui.dp(this, 12), 0, 0, 0);
        r2.addView(countLbl);
        LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(-1, -2);
        r2lp.topMargin = Ui.dp(this, 8);
        col.addView(r2, r2lp);

        // corpo: gruppi a sinistra, elenco a destra
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, 0, 1f);
        blp.topMargin = Ui.dp(this, 8);
        col.addView(body, blp);

        catList = new ListView(this);
        catList.setDivider(null);
        catList.setSelector(Ui.selector());
        catAd = new BaseAdapter() {
            @Override
            public int getCount() {
                return catLabels.size();
            }

            @Override
            public Object getItem(int i) {
                return catLabels.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                LinearLayout row;
                TextView name;
                TextView cnt;
                if (cv instanceof LinearLayout && cv.getTag() instanceof TextView[]) {
                    row = (LinearLayout) cv;
                    TextView[] t = (TextView[]) cv.getTag();
                    name = t[0];
                    cnt = t[1];
                } else {
                    row = new LinearLayout(BrowseActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(Ui.dp(BrowseActivity.this, 12), Ui.dp(BrowseActivity.this, 12),
                            Ui.dp(BrowseActivity.this, 10), Ui.dp(BrowseActivity.this, 12));
                    name = new TextView(BrowseActivity.this);
                    name.setTextSize(17);
                    name.setSingleLine(true);
                    name.setEllipsize(TextUtils.TruncateAt.END);
                    row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
                    cnt = new TextView(BrowseActivity.this);
                    cnt.setTextSize(14);
                    cnt.setTextColor(Ui.MUTE);
                    cnt.setPadding(Ui.dp(BrowseActivity.this, 8), 0, 0, 0);
                    row.addView(cnt, new LinearLayout.LayoutParams(-2, -2));
                    row.setTag(new TextView[]{name, cnt});
                }
                name.setText(catLabels.get(i));
                name.setTextColor(i == catIdx ? Ui.ACC : Ui.TEXT);
                cnt.setText(i < catCounts.size() ? String.valueOf(catCounts.get(i)) : "");
                return row;
            }
        };
        catList.setAdapter(catAd);
        catList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                pickCat(pos);
                itemList.requestFocus();
            }
        });
        catList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                pickCat(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        body.addView(catList, new LinearLayout.LayoutParams(0, -1, 1f));

        FrameLayout right = new FrameLayout(this);
        itemList = new ListView(this);
        itemList.setDivider(null);
        itemList.setSelector(Ui.selector());
        itemAd = new ItemAdapter();
        itemList.setAdapter(itemAd);
        itemList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) choose(shown.get(pos), pos);
            }
        });
        itemList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) fav(shown.get(pos));
                return true;
            }
        });
        itemList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                epgPos = pos;
                Repo.ui.removeCallbacks(epgRun);
                Repo.ui.postDelayed(epgRun, 500);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        right.addView(itemList, new FrameLayout.LayoutParams(-1, -1));

        statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.VERTICAL);
        statusBox.setGravity(Gravity.CENTER);
        statusBox.setBackgroundColor(0x00000000);
        status = Ui.text(this, "", 18, Ui.TEXT);
        status.setGravity(Gravity.CENTER);
        status.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        statusBox.addView(status, new LinearLayout.LayoutParams(-2, -2));
        retry = Ui.button(this, "Riprova");
        retry.setVisibility(View.GONE);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectSection(sec, true);
            }
        });
        statusBox.addView(retry, new LinearLayout.LayoutParams(-2, -2));
        statusBox.setVisibility(View.GONE);
        right.addView(statusBox, new FrameLayout.LayoutParams(-1, -1));
        body.addView(right, new LinearLayout.LayoutParams(0, -1, 2.2f));

        setContentView(root);
    }

    private final class ItemAdapter extends BaseAdapter {
        private final class Holder {
            ImageView logo;
            TextView name;
            TextView sub;
        }

        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int i) {
            return shown.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View cv, ViewGroup parent) {
            Holder h;
            if (cv == null) {
                LinearLayout row = new LinearLayout(BrowseActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(BrowseActivity.this, 10), Ui.dp(BrowseActivity.this, 6),
                        Ui.dp(BrowseActivity.this, 10), Ui.dp(BrowseActivity.this, 6));
                row.setMinimumHeight(Ui.dp(BrowseActivity.this, 64));
                h = new Holder();
                h.logo = new ImageView(BrowseActivity.this);
                h.logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
                row.addView(h.logo, new LinearLayout.LayoutParams(Ui.dp(BrowseActivity.this, 52),
                        Ui.dp(BrowseActivity.this, 52)));
                LinearLayout txt = new LinearLayout(BrowseActivity.this);
                txt.setOrientation(LinearLayout.VERTICAL);
                h.name = Ui.text(BrowseActivity.this, "", 18, Ui.TEXT);
                h.name.setSingleLine(true);
                h.sub = Ui.text(BrowseActivity.this, "", 13, Ui.MUTE);
                h.sub.setSingleLine(true);
                txt.addView(h.name);
                txt.addView(h.sub);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
                tl.leftMargin = Ui.dp(BrowseActivity.this, 12);
                row.addView(txt, tl);
                row.setTag(h);
                cv = row;
            } else {
                h = (Holder) cv.getTag();
            }
            Item it = shown.get(i);
            Img.load(h.logo, it.logo);
            h.name.setText((Repo.favs.contains(it.url) ? "★ " : "") + it.name);
            h.name.setTextColor(it == Repo.nowPlaying ? Ui.ACC : Ui.TEXT);
            String sub = it.group;
            if (it.type == 0) {
                Item.Prog pr = it.now();
                if (pr != null) sub = pr.t;
            }
            h.sub.setText(sub);
            return cv;
        }
    }

    // ------------------------------------------------------------ dati

    private void status(String m, boolean showRetry) {
        if (m == null || m.length() == 0) {
            statusBox.setVisibility(View.GONE);
            return;
        }
        status.setText(m);
        retry.setVisibility(showRetry ? View.VISIBLE : View.GONE);
        statusBox.setVisibility(View.VISIBLE);
    }

    private void updateTabs() {
        for (int i = 0; i < 3; i++) {
            tabs[i].setTextColor(i == sec ? Ui.ACC : Ui.TEXT);
        }
    }

    private void clearLists() {
        catKeys.clear();
        catLabels.clear();
        catCounts.clear();
        shown = new ArrayList<Item>();
        catAd.notifyDataSetChanged();
        itemAd.notifyDataSetChanged();
        countLbl.setText("");
    }

    private static final long MAX_AGE = 12L * 3600L * 1000L;

    private void selectSection(int n) {
        selectSection(n, false);
    }

    /** Legge l'elenco dalla cache se e' recente, altrimenti lo scarica e lo salva. */
    private List<Item> loadXtream(int n, boolean force) throws Exception {
        String ck = "x_" + Repo.acc.key() + "_" + n;
        if (!force) {
            String c = Cache.get(this, ck + "_c", MAX_AGE);
            String s = Cache.get(this, ck + "_s", MAX_AGE);
            if (c != null && s != null) {
                try {
                    return Repo.x.parse(n, c, s);
                } catch (Exception e) {
                    // cache rovinata: si scarica di nuovo
                }
            }
        }
        String[] r = Repo.x.fetch(n);
        List<Item> l = Repo.x.parse(n, r[0], r[1]);
        Cache.put(this, ck + "_c", r[0]);
        Cache.put(this, ck + "_s", r[1]);
        return l;
    }

    private void selectSection(final int n, final boolean force) {
        sec = n;
        updateTabs();
        search.setText("");
        query = "";
        status("", false);
        if (!force && Repo.loaded[n]) {
            buildCats();
            return;
        }
        clearLists();
        status("Carico...", false);
        Repo.pool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final List<Item> l;
                    final List<List<Item>> parts;
                    if (Repo.isX) {
                        l = loadXtream(n, force);
                        parts = null;
                    } else {
                        l = null;
                        parts = M3u.split(M3u.parse(Net.getRetry(Repo.acc.m3u, 90000)));
                    }
                    Repo.ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (parts != null) {
                                for (int k = 0; k < 3; k++) {
                                    Repo.data.set(k, parts.get(k));
                                    Repo.loaded[k] = true;
                                }
                            } else {
                                Repo.data.set(n, l);
                                Repo.loaded[n] = true;
                            }
                            if (sec == n) {
                                buildCats();
                                if (n == 0) maybeAutoplay();
                            }
                        }
                    });
                } catch (final Exception e) {
                    Repo.ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (sec == n) {
                                status("Impossibile caricare (" + e.getMessage()
                                        + ").\nControlla i dati dell'account (tasto Account).", true);
                            }
                        }
                    });
                }
            }
        });
    }

    private void addCat(String g, int count) {
        catKeys.add(g);
        catLabels.add(g);
        catCounts.add(count);
    }

    private void buildCats() {
        List<Item> all = Repo.data.get(sec);
        if (all.isEmpty()) {
            clearLists();
            status(sec == 0 ? "Nessun canale in questa sezione."
                    : sec == 1 ? "Nessun film in questa playlist."
                    : "Nessuna serie in questa playlist.", false);
            return;
        }
        status("", false);
        LinkedHashMap<String, Integer> m = new LinkedHashMap<String, Integer>();
        int fav = 0;
        for (Item it : all) {
            Integer c = m.get(it.group);
            m.put(it.group, c == null ? 1 : c + 1);
            if (Repo.favs.contains(it.url)) fav++;
        }
        catKeys.clear();
        catLabels.clear();
        catCounts.clear();
        catKeys.add("#all");
        catLabels.add("Tutti");
        catCounts.add(all.size());
        catKeys.add("#fav");
        catLabels.add("★ Preferiti");
        catCounts.add(fav);
        // prima nell'ordine del server, poi quelli rimasti nell'ordine della playlist
        List<String> done = new ArrayList<String>();
        for (String g : Repo.catOrder.get(sec)) {
            if (m.containsKey(g) && !done.contains(g)) {
                addCat(g, m.get(g));
                done.add(g);
            }
        }
        for (Map.Entry<String, Integer> e : m.entrySet()) {
            if (!done.contains(e.getKey())) addCat(e.getKey(), e.getValue());
        }
        String last = Prefs.cat(this, sec);
        catIdx = last == null ? 0 : Math.max(0, catKeys.indexOf(last));
        catAd.notifyDataSetChanged();
        catList.setSelection(catIdx);
        refreshItems();
        itemList.requestFocus();
    }

    private void pickCat(int pos) {
        if (pos < 0 || pos >= catKeys.size() || pos == catIdx) return;
        catIdx = pos;
        Prefs.setCat(this, sec, catKeys.get(pos));
        catAd.notifyDataSetChanged();
        refreshItems();
    }

    private void refreshItems() {
        if (catKeys.isEmpty() || catIdx >= catKeys.size()) return;
        List<Item> all = Repo.data.get(sec);
        String key = catKeys.get(catIdx);
        String q = query.trim().toLowerCase(Locale.getDefault());
        List<Item> l = new ArrayList<Item>();
        for (Item it : all) {
            if (q.length() > 0) {
                if (it.name.toLowerCase(Locale.getDefault()).contains(q)) l.add(it);
            } else if (key.equals("#all") || (key.equals("#fav") && Repo.favs.contains(it.url))
                    || key.equals(it.group)) {
                l.add(it);
            }
        }
        shown = l;
        itemAd.notifyDataSetChanged();
        itemList.setSelection(0);
        String unit = sec == 0 ? " canali" : sec == 1 ? " film" : " serie";
        countLbl.setText(l.size() + unit);
        if (l.isEmpty()) {
            status(key.equals("#fav") && q.length() == 0
                    ? "Nessun preferito.\nTieni premuto OK (o tasto Verde) su un titolo per aggiungerlo."
                    : "Nessun risultato.", false);
        } else {
            status("", false);
        }
    }

    private void updateFavLabel() {
        if (catLabels.size() > 1) {
            int fav = 0;
            for (Item it : Repo.data.get(sec)) {
                if (Repo.favs.contains(it.url)) fav++;
            }
            catCounts.set(1, fav);
            catAd.notifyDataSetChanged();
        }
    }

    private void fav(Item it) {
        Repo.toggleFav(this, it);
        Toast.makeText(this, (Repo.favs.contains(it.url) ? "Aggiunto ai preferiti: " : "Tolto dai preferiti: ") + it.name,
                Toast.LENGTH_SHORT).show();
        updateFavLabel();
        if (catIdx == 1) {
            int keep = itemList.getSelectedItemPosition();
            refreshItems();
            if (keep > 0 && keep < shown.size()) itemList.setSelection(keep);
        } else {
            itemAd.notifyDataSetChanged();
        }
    }

    // ------------------------------------------------------------ azioni

    private void choose(Item it, int pos) {
        if (it.type == 2) {
            openSeries(it);
            return;
        }
        Repo.playlist = new ArrayList<Item>(shown);
        Repo.index = pos;
        startActivity(new Intent(this, PlayerActivity.class));
    }

    private void openSeries(final Item series) {
        if (series.eps != null) {
            showEpisodes(series, series.eps);
            return;
        }
        Toast.makeText(this, "Carico gli episodi...", Toast.LENGTH_SHORT).show();
        Repo.pool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final List<Item> eps = Repo.x.episodes(series);
                    Repo.ui.post(new Runnable() {
                        @Override
                        public void run() {
                            showEpisodes(series, eps);
                        }
                    });
                } catch (final Exception e) {
                    Repo.ui.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(BrowseActivity.this, "Episodi non disponibili (" + e.getMessage() + ")",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void showEpisodes(Item series, final List<Item> eps) {
        if (eps.isEmpty()) {
            Toast.makeText(this, "Nessun episodio trovato", Toast.LENGTH_LONG).show();
            return;
        }
        CharSequence[] names = new CharSequence[eps.size()];
        for (int i = 0; i < eps.size(); i++) {
            names[i] = eps.get(i).name;
        }
        new AlertDialog.Builder(this)
                .setTitle(series.name)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Repo.playlist = eps;
                        Repo.index = which;
                        startActivity(new Intent(BrowseActivity.this, PlayerActivity.class));
                    }
                })
                .show();
    }

    /** All'apertura dell'app: torna all'ultimo canale guardato. */
    private void maybeAutoplay() {
        if (!Repo.boot) return;
        Repo.boot = false;
        String last = Prefs.last(this);
        if (last == null) return;
        for (Item it : Repo.data.get(0)) {
            if (last.equals(it.url)) {
                int ci = catKeys.indexOf(it.group);
                if (ci < 0) return;
                catIdx = ci;
                catAd.notifyDataSetChanged();
                refreshItems();
                int pos = shown.indexOf(it);
                if (pos < 0) return;
                itemList.setSelection(pos);
                Repo.playlist = new ArrayList<Item>(shown);
                Repo.index = pos;
                startActivity(new Intent(this, PlayerActivity.class));
                return;
            }
        }
    }

    private void openAccounts() {
        startActivity(new Intent(this, AccountsActivity.class).putExtra("manage", true));
        finish();
    }

    private void menu() {
        new AlertDialog.Builder(this)
                .setItems(new CharSequence[]{"Account", "Cerca", "Aggiorna elenco", "Esci"},
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (which == 0) openAccounts();
                                else if (which == 1) search.requestFocus();
                                else if (which == 2) selectSection(sec, true);
                                else Ui.confirmExit(BrowseActivity.this);
                            }
                        })
                .show();
    }

    // ------------------------------------------------------------ telecomando

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        boolean inSearch = getCurrentFocus() == search;
        switch (k) {
            case KeyEvent.KEYCODE_BACK:
                if (inSearch && search.getText().length() > 0) {
                    search.setText("");
                } else {
                    Ui.confirmExit(this);
                }
                return true;
            case KeyEvent.KEYCODE_PROG_GREEN: {
                int p = itemList.getSelectedItemPosition();
                if (p >= 0 && p < shown.size()) fav(shown.get(p));
                return true;
            }
            case KeyEvent.KEYCODE_PROG_RED:
                openAccounts();
                return true;
            case KeyEvent.KEYCODE_PROG_YELLOW:
                search.requestFocus();
                return true;
            case KeyEvent.KEYCODE_PROG_BLUE:
                selectSection((sec + 1) % 3);
                return true;
            case KeyEvent.KEYCODE_MENU:
                menu();
                return true;
            case KeyEvent.KEYCODE_1:
            case KeyEvent.KEYCODE_2:
            case KeyEvent.KEYCODE_3:
                if (!inSearch) {
                    selectSection(k - KeyEvent.KEYCODE_1);
                    return true;
                }
                break;
            default:
                break;
        }
        return super.onKeyDown(k, e);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Updater.resume(this);
        if (itemAd == null) return;
        updateFavLabel();
        itemAd.notifyDataSetChanged();
        if (Repo.nowPlaying != null) {
            int p = shown.indexOf(Repo.nowPlaying);
            if (p >= 0) itemList.setSelection(p);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }
}
