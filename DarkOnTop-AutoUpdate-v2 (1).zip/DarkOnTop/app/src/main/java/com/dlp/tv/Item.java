package com.dlp.tv;

import java.util.List;

/** Un canale, un film, una serie o un episodio. */
final class Item {
    static final class Prog {
        final long s;
        final long e;
        final String t;

        Prog(long s, long e, String t) {
            this.s = s;
            this.e = e;
            this.t = t;
        }
    }

    String name = "";
    String logo = "";
    String group = "Altri";
    String url = "";
    String epgId = "";
    int type = 0;          // 0 live, 1 film, 2 serie, 3 episodio
    int sid = -1;          // id del canale live (per la guida)
    int seriesId = -1;     // id della serie
    List<Prog> epg;
    long epgAt = 0;
    List<Item> eps;        // episodi gia' noti (serie da playlist M3U)
    int ord = 0;           // stagione*1000 + episodio, per mettere in ordine

    Prog now() {
        if (epg == null) return null;
        long t = System.currentTimeMillis();
        for (Prog p : epg) {
            if (p.s <= t && t < p.e) return p;
        }
        return null;
    }

    Prog next() {
        if (epg == null) return null;
        long t = System.currentTimeMillis();
        for (Prog p : epg) {
            if (p.s > t) return p;
        }
        return null;
    }
}
