package com.dlp.tv;

import android.util.Base64;

/** Account demo integrato. Il link e' offuscato (XOR + Base64). */
final class Demo {
    static final String NAME = "Dark-Demo";

    private static final byte[] KEY = {68, 52, 114, 107, 48, 110, 84, 48, 112};
    private static final String DATA =
            "LEAGGwpBe1gFKEFcBFwKNVQGIVoGHkILel8CIw5AWABeZB8XIUBcG1gea0UDIUYcCl0LaXwlB38r"
                    + "RnwnGnVWNFUBGEcBJlRNHlERGgQqHghEARIGEkALaV1DMWsCB0Ud";

    static String url() {
        try {
            byte[] b = Base64.decode(DATA, Base64.DEFAULT);
            for (int i = 0; i < b.length; i++) {
                b[i] = (byte) (b[i] ^ KEY[i % KEY.length]);
            }
            return new String(b, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    static Account account() {
        Account a = new Account();
        a.name = NAME;
        a.m3u = url();
        if (!Account.tryDerive(a)) {
            a.m3u = url();
        }
        return a;
    }
}
