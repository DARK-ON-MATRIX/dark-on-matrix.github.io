package com.dlp.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Dati salvati sul dispositivo: account, preferiti, ultimo canale, ultimo gruppo. */
final class Prefs {
    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("dlp", Context.MODE_PRIVATE);
    }

    static List<Account> accounts(Context c) {
        List<Account> out = new ArrayList<Account>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("accounts", "[]"));
            for (int i = 0; i < a.length(); i++) {
                out.add(Account.fromJson(a.getJSONObject(i)));
            }
        } catch (Exception e) {
            // lista vuota
        }
        boolean changed = false;
        for (Account a : out) {
            if (Account.tryDerive(a)) changed = true;
        }
        if (out.isEmpty()) {
            Account d = Demo.account();
            if (d.isXtream() || d.m3u.length() > 0) {
                out.add(d);
                changed = true;
            }
        }
        if (changed) saveAccounts(c, out);
        return out;
    }

    static void saveAccounts(Context c, List<Account> list) {
        try {
            JSONArray a = new JSONArray();
            for (Account x : list) {
                a.put(x.toJson());
            }
            sp(c).edit().putString("accounts", a.toString()).apply();
        } catch (Exception e) {
            // ignora
        }
    }

    static int active(Context c) {
        return sp(c).getInt("active", 0);
    }

    static void setActive(Context c, int i) {
        sp(c).edit().putInt("active", i).apply();
    }

    static Set<String> favs(Context c) {
        Set<String> s = new HashSet<String>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("favs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                s.add(a.getString(i));
            }
        } catch (Exception e) {
            // vuoto
        }
        return s;
    }

    static void saveFavs(Context c, Set<String> s) {
        JSONArray a = new JSONArray();
        for (String x : s) {
            a.put(x);
        }
        sp(c).edit().putString("favs", a.toString()).apply();
    }

    static String last(Context c) {
        return sp(c).getString("last_" + Repo.acc.key(), null);
    }

    static void setLast(Context c, String url) {
        sp(c).edit().putString("last_" + Repo.acc.key(), url).apply();
    }

    static String cat(Context c, int sec) {
        return sp(c).getString("cat_" + Repo.acc.key() + "_" + sec, null);
    }

    static void setCat(Context c, int sec, String name) {
        sp(c).edit().putString("cat_" + Repo.acc.key() + "_" + sec, name).apply();
    }
}
