package com.dlp.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Controlla su GitHub Pages se c'e' una versione nuova, la scarica e apre l'installazione. */
final class Updater {
    private static final String VERSION_URL = "https://dark-on-matrix.github.io/version.json";
    private static boolean checked = false;
    private static File pending = null;

    static void check(final Activity a) {
        if (checked) return;
        checked = true;
        Repo.pool.execute(new Runnable() {
            @Override
            public void run() {
                final JSONObject o = fetch();
                if (o == null) return;
                final int code = o.optInt("versionCode", 0);
                final String name = o.optString("versionName", "");
                final String apk = o.optString("apk", "");
                if (code <= currentCode(a) || apk.length() == 0) return;
                Repo.ui.post(new Runnable() {
                    @Override
                    public void run() {
                        ask(a, code, name, apk);
                    }
                });
            }
        });
    }

    private static int currentCode(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private static JSONObject fetch() {
        try {
            return new JSONObject(Net.get(VERSION_URL, 8000));
        } catch (Exception e) {
            return null;
        }
    }

    private static void ask(final Activity a, final int code, final String name, final String apk) {
        if (a.isFinishing() || a.isDestroyed()) return;
        String v = name.length() > 0 ? name : String.valueOf(code);
        new AlertDialog.Builder(a)
                .setTitle("Aggiornamento disponibile")
                .setMessage("Nuova versione " + v + "\nVuoi aggiornare ora?")
                .setPositiveButton("Aggiorna", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        download(a, apk);
                    }
                })
                .setNegativeButton("Dopo", null)
                .show();
    }

    private static void download(final Activity a, final String apkUrl) {
        Toast.makeText(a, "Download aggiornamento...", Toast.LENGTH_SHORT).show();
        Repo.pool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File dir = new File(a.getCacheDir(), "updates");
                    if (!dir.exists()) dir.mkdirs();
                    final File f = new File(dir, "DarkOnTop.apk");
                    HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setRequestProperty("User-Agent", Net.UA);
                    c.setInstanceFollowRedirects(true);
                    InputStream in = c.getInputStream();
                    FileOutputStream out = new FileOutputStream(f);
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    out.close();
                    c.disconnect();
                    Repo.ui.post(new Runnable() {
                        @Override
                        public void run() {
                            install(a, f);
                        }
                    });
                } catch (final Exception e) {
                    Repo.ui.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(a, "Download non riuscito: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private static void install(Activity a, File f) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            pending = f;
            Toast.makeText(a, "Consenti l'installazione da questa app, poi torna qui.",
                    Toast.LENGTH_LONG).show();
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + a.getPackageName())));
            } catch (Exception e) {
                // impostazioni non disponibili
            }
            return;
        }
        installNow(a, f);
    }

    /** Riprende l'installazione al ritorno dalle impostazioni. */
    static void resume(Activity a) {
        if (pending == null) return;
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) return;
        File f = pending;
        pending = null;
        installNow(a, f);
    }

    private static void installNow(Activity a, File f) {
        Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            a.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(a, "Impossibile aprire l'installer: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
