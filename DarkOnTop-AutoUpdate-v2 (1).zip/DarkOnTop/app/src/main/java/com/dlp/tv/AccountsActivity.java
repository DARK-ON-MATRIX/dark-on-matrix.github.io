package com.dlp.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Schermata iniziale: scegli o aggiungi un account. Se ne esiste uno, si apre direttamente. */
public class AccountsActivity extends Activity {
    private List<Account> list;
    private BaseAdapter ad;
    private boolean manage;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        manage = getIntent().getBooleanExtra("manage", false);
        list = Prefs.accounts(this);
        if (!manage && !list.isEmpty()) {
            int a = Prefs.active(this);
            if (a < 0 || a >= list.size()) a = 0;
            open(a, true);
            return;
        }
        Ui.immersive(this);
        build();
        if (list.isEmpty()) form(-1);
    }

    private void open(int i, boolean boot) {
        Repo.open(this, i);
        if (!boot) Repo.boot = false;
        startActivity(new Intent(this, BrowseActivity.class));
        finish();
    }

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Bitmap bm = Ui.asset(this, "bg.jpg");
        if (bm != null) bg.setImageBitmap(bm);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View dim = new View(this);
        dim.setBackgroundColor(0xCC0E1317);
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(this, 640), -1);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(col, lp);

        ImageView banner = new ImageView(this);
        banner.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap bn = Ui.asset(this, "logo.jpg");
        if (bn != null) banner.setImageBitmap(bn);
        col.addView(banner, new LinearLayout.LayoutParams(-1, Ui.dp(this, 150)));

        TextView title = Ui.text(this, "I miei account", 22, Ui.TEXT);
        title.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 8));
        col.addView(title);

        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(Ui.selector());
        ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return list.size();
            }

            @Override
            public Object getItem(int p) {
                return list.get(p);
            }

            @Override
            public long getItemId(int p) {
                return p;
            }

            @Override
            public View getView(int p, View cv, ViewGroup parent) {
                LinearLayout row = new LinearLayout(AccountsActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(Ui.dp(AccountsActivity.this, 12), Ui.dp(AccountsActivity.this, 10),
                        Ui.dp(AccountsActivity.this, 12), Ui.dp(AccountsActivity.this, 10));
                Account a = list.get(p);
                row.addView(Ui.text(AccountsActivity.this, a.name, 20, Ui.TEXT));
                String sub = a.isXtream() ? "Xtream · " + a.server + " · " + a.user : "Playlist M3U";
                row.addView(Ui.text(AccountsActivity.this, sub, 13, Ui.MUTE));
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                options(pos);
            }
        });
        col.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));

        Button add = Ui.button(this, "+ Aggiungi account");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                form(-1);
            }
        });
        col.addView(add, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        lv.requestFocus();
    }

    private void options(final int pos) {
        new AlertDialog.Builder(this)
                .setTitle(list.get(pos).name)
                .setItems(new CharSequence[]{"Apri", "Modifica", "Elimina"},
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (which == 0) open(pos, false);
                                else if (which == 1) form(pos);
                                else confirmDelete(pos);
                            }
                        })
                .show();
    }

    private void confirmDelete(final int pos) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminare \"" + list.get(pos).name + "\"?")
                .setPositiveButton("Elimina", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Account gone = list.remove(pos);
                        if (Repo.acc != null && Repo.acc.key().equals(gone.key())) Repo.acc = null;
                        Prefs.saveAccounts(AccountsActivity.this, list);
                        Prefs.setActive(AccountsActivity.this, 0);
                        ad.notifyDataSetChanged();
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    private EditText field(LinearLayout box, String label, String value, int inputType) {
        TextView t = Ui.text(this, label, 13, Ui.MUTE);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 3));
        box.addView(t);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setInputType(inputType);
        e.setText(value);
        box.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void form(final int idx) {
        final Account a = idx >= 0 ? list.get(idx) : new Account();
        if (idx < 0) a.server = Account.DEFAULT_SERVER;
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, pad / 2, pad, 0);
        sv.addView(box);
        final EditText fn = field(box, "Nome account (facoltativo)", a.name,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        final EditText fs = field(box, "Server Xtream (già impostato, puoi cambiarlo)", a.server,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        final EditText fu = field(box, "Utente", a.user,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        final EditText fp = field(box, "Password", a.pass,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        CheckBox cb = new CheckBox(this);
        cb.setText("Mostra password");
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                fp.setTransformationMethod(on ? null : PasswordTransformationMethod.getInstance());
                fp.setSelection(fp.getText().length());
            }
        });
        box.addView(cb);
        final EditText fm = field(box, "Oppure playlist M3U/M3U8 (al posto di utente e password)", a.m3u,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(idx < 0 ? "Nuovo account" : "Modifica account")
                .setView(sv)
                .setPositiveButton("Salva", null)
                .setNegativeButton("Annulla", null)
                .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String srv = fs.getText().toString().trim();
                String usr = fu.getText().toString().trim();
                String pwd = fp.getText().toString();
                String m3u = fm.getText().toString().trim();
                if (usr.length() > 0 && pwd.length() > 0 && srv.length() == 0) srv = Account.DEFAULT_SERVER;
                boolean x = srv.length() > 0 && usr.length() > 0 && pwd.length() > 0;
                if (!x && m3u.length() > 0) {
                    Account t = new Account();
                    t.m3u = m3u;
                    if (Account.tryDerive(t)) {
                        srv = t.server;
                        usr = t.user;
                        pwd = t.pass;
                        m3u = "";
                        x = true;
                    }
                }
                if (!x && m3u.length() == 0) {
                    Toast.makeText(AccountsActivity.this,
                            "Inserisci utente e password, oppure un indirizzo M3U", Toast.LENGTH_LONG).show();
                    return;
                }
                Account n = idx >= 0 ? list.get(idx) : new Account();
                n.name = fn.getText().toString().trim();
                if (n.name.length() == 0) n.name = "Account " + (idx >= 0 ? idx + 1 : list.size() + 1);
                n.server = x ? srv : "";
                n.user = x ? usr : "";
                n.pass = x ? pwd : "";
                n.m3u = m3u;
                if (idx < 0) list.add(n);
                Prefs.saveAccounts(AccountsActivity.this, list);
                d.dismiss();
                if (ad != null) ad.notifyDataSetChanged();
                if (idx < 0) open(list.size() - 1, false);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (manage && Repo.acc != null) {
            startActivity(new Intent(this, BrowseActivity.class));
            finish();
        } else {
            Ui.confirmExit(this);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }
}
