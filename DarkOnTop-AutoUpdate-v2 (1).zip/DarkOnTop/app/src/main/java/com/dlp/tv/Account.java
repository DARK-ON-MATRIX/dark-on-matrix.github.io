package com.dlp.tv;

import org.json.JSONException;
import org.json.JSONObject;

/** Un account: Xtream Codes (server, utente, password) oppure una playlist M3U. */
final class Account {
    static final String DEFAULT_SERVER = "http://wearelegion.hopto.org";

    String name = "";
    String server = "";
    String user = "";
    String pass = "";
    String m3u = "";

    /** Se il link M3U contiene username e password (get.php), lo trasforma in account Xtream. */
    static boolean tryDerive(Account a) {
        try {
            if (a.isXtream() || a.m3u.length() == 0) return false;
            java.net.URL u = new java.net.URL(a.m3u);
            String q = u.getQuery();
            if (q == null) return false;
            String user = null;
            String pass = null;
            for (String kv : q.split("&")) {
                int i = kv.indexOf('=');
                if (i < 0) continue;
                String k = kv.substring(0, i);
                String v = java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
                if (k.equals("username")) user = v;
                else if (k.equals("password")) pass = v;
            }
            if (user == null || pass == null || user.length() == 0 || pass.length() == 0) return false;
            a.server = u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
            a.user = user;
            a.pass = pass;
            a.m3u = "";
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    boolean isXtream() {
        return server.length() > 0 && user.length() > 0 && pass.length() > 0;
    }

    String key() {
        return Integer.toHexString((server + "|" + user + "|" + m3u).hashCode());
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("name", name);
        o.put("server", server);
        o.put("user", user);
        o.put("pass", pass);
        o.put("m3u", m3u);
        return o;
    }

    static Account fromJson(JSONObject o) {
        Account a = new Account();
        a.name = o.optString("name");
        a.server = o.optString("server");
        a.user = o.optString("user");
        a.pass = o.optString("pass");
        a.m3u = o.optString("m3u");
        return a;
    }
}
