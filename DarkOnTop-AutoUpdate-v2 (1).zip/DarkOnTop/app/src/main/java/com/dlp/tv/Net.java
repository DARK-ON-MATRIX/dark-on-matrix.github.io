package com.dlp.tv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

/** Scarica testo da internet (segue anche i reindirizzamenti da http a https). */
final class Net {
    static final String UA = "VLC/3.0.20 LibVLC/3.0.20";

    static String get(String u, int readTimeoutMs) throws IOException {
        String cur = u;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            try {
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(readTimeoutMs);
                c.setRequestProperty("User-Agent", UA);
                c.setRequestProperty("Accept-Encoding", "gzip");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) throw new IOException("reindirizzamento non valido");
                    cur = new URL(new URL(cur), loc).toString();
                    continue;
                }
                if (code >= 400) throw new IOException("errore " + code);
                InputStream in = c.getInputStream();
                if ("gzip".equalsIgnoreCase(c.getContentEncoding())) {
                    in = new GZIPInputStream(in);
                }
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                in.close();
                return out.toString("UTF-8");
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("troppi reindirizzamenti");
    }

    /** Come get, ma riprova fino a 3 volte se il server non risponde. */
    static String getRetry(String u, int readTimeoutMs) throws IOException {
        IOException last = null;
        for (int i = 0; i < 3; i++) {
            try {
                return get(u, readTimeoutMs);
            } catch (IOException e) {
                last = e;
                String m = String.valueOf(e.getMessage());
                if (m.startsWith("errore 4")) throw e;   // inutile riprovare
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }
        throw last != null ? last : new IOException("server non raggiungibile");
    }
}
