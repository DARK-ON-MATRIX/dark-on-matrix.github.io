package com.dlp.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.InputStream;

/** Colori e piccoli aiuti per la grafica. */
final class Ui {
    static final int BG = 0xFF0E1317;
    static final int PANEL = 0xFF161E25;
    static final int ACC = 0xFF41D1C4;
    static final int TEXT = 0xFFE9EFF3;
    static final int MUTE = 0xFF7F909C;

    static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    @SuppressWarnings("deprecation")
    static void immersive(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    static Bitmap asset(Context c, String name) {
        InputStream in = null;
        try {
            in = c.getAssets().open(name);
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Exception e) {
                // niente
            }
        }
    }

    static TextView text(Context c, String t, int sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        return v;
    }

    private static GradientDrawable box(Context c, int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(c, 3), stroke);
        g.setCornerRadius(dp(c, 6));
        return g;
    }

    /** Sfondo con bordo colorato quando il pulsante e' selezionato col telecomando. */
    static StateListDrawable focusBg(Context c, int fill) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, box(c, fill, ACC));
        s.addState(new int[]{android.R.attr.state_pressed}, box(c, fill, ACC));
        s.addState(new int[]{}, box(c, fill, Color.TRANSPARENT));
        return s;
    }

    static Button button(Context c, String t) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTextSize(15);
        b.setPadding(dp(c, 14), dp(c, 6), dp(c, 14), dp(c, 6));
        b.setBackground(focusBg(c, PANEL));
        b.setFocusable(true);
        return b;
    }

    static EditText edit(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(MUTE);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setBackground(focusBg(c, PANEL));
        e.setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
        return e;
    }

    static ColorDrawable selector() {
        return new ColorDrawable(0x5541D1C4);
    }

    /** "Vuoi uscire dall'applicazione?" con Si' verde e No rosso. */
    static void confirmExit(final Activity a) {
        final AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("Vuoi uscire dall'applicazione?")
                .setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        a.finishAffinity();
                    }
                })
                .setNegativeButton("No", null)
                .create();
        d.show();
        Button yes = d.getButton(AlertDialog.BUTTON_POSITIVE);
        Button no = d.getButton(AlertDialog.BUTTON_NEGATIVE);
        yes.setBackgroundColor(0xFF1F9D4A);
        yes.setTextColor(Color.WHITE);
        no.setBackgroundColor(0xFFD63B3B);
        no.setTextColor(Color.WHITE);
        no.requestFocus();
    }
}
