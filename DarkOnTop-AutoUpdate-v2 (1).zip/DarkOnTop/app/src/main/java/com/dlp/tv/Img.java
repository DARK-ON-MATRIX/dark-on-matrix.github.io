package com.dlp.tv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Carica i loghi dei canali in modo leggero. */
final class Img {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(120);
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);

    static void load(final ImageView v, final String url) {
        v.setTag(url);
        v.setImageDrawable(null);
        if (url == null || url.length() == 0) return;
        Bitmap b = CACHE.get(url);
        if (b != null) {
            v.setImageBitmap(b);
            return;
        }
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setRequestProperty("User-Agent", Net.UA);
                    InputStream in = c.getInputStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0 && out.size() < 3000000) {
                        out.write(buf, 0, n);
                    }
                    in.close();
                    c.disconnect();
                    byte[] data = out.toByteArray();
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    int s = 1;
                    while (o.outWidth / (s * 2) >= 160 && o.outHeight / (s * 2) >= 160) {
                        s *= 2;
                    }
                    o = new BitmapFactory.Options();
                    o.inSampleSize = s;
                    final Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    if (bm == null) return;
                    CACHE.put(url, bm);
                    v.post(new Runnable() {
                        @Override
                        public void run() {
                            if (url.equals(v.getTag())) v.setImageBitmap(bm);
                        }
                    });
                } catch (Exception e) {
                    // logo non disponibile
                }
            }
        });
    }
}
