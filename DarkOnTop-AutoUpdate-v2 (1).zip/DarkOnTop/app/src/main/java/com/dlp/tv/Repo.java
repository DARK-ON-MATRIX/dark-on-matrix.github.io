package com.dlp.tv;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Stato condiviso tra le schermate dell'app. */
final class Repo {
    static Account acc;
    static Xtream x;
    static boolean isX;
    static boolean boot = true;               // vero solo all'apertura dell'app
    static final List<List<Item>> data = new ArrayList<List<Item>>();
    static final boolean[] loaded = new boolean[3];
    static final List<List<String>> catOrder = new ArrayList<List<String>>();
    static List<Item> playlist;
    static int index;
    static Item nowPlaying;
    static Set<String> favs = new HashSet<String>();
    static final ExecutorService pool = Executors.newFixedThreadPool(3);
    static final Handler ui = new Handler(Looper.getMainLooper());

    static {
        for (int i = 0; i < 3; i++) {
            data.add(new ArrayList<Item>());
            catOrder.add(new ArrayList<String>());
        }
    }

    static void open(Context c, int i) {
        List<Account> l = Prefs.accounts(c);
        if (i < 0 || i >= l.size()) i = 0;
        acc = l.get(i);
        Prefs.setActive(c, i);
        isX = acc.isXtream();
        x = isX ? new Xtream(acc) : null;
        for (int k = 0; k < 3; k++) {
            data.set(k, new ArrayList<Item>());
            catOrder.set(k, new ArrayList<String>());
            loaded[k] = false;
        }
        favs = Prefs.favs(c);
        playlist = null;
        nowPlaying = null;
    }

    static void toggleFav(Context c, Item it) {
        if (favs.contains(it.url)) {
            favs.remove(it.url);
        } else {
            favs.add(it.url);
        }
        Prefs.saveFavs(c, favs);
    }
}
